/* config.h */
#define USE_REGEX
#define USE_TIGGE
//#define DISABLE_TIMEZONE
//#define USE_UDF
//#define USE_IPOLATES
#define USE_G2CLIB
#define USE_PROJ4
#define USE_JASPER
//#define USE_AEC "libaec-1.0.0.tar.gz"
//#define USE_NETCDF3
#define USE_NETCDF4
//#define USE_MYSQL
#define CC "cc"
#define FORTRAN "g77"
#define BUILD_COMMENTS "stock build"
#define USE_PNG
//#define WMO_VALIDATION
