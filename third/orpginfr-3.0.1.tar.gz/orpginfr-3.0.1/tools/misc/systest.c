



#include <config.h>
#include <stdio.h>
#include <infr.h>

int main ()
{
    int ret;

    MISC_system_shell ("/bin/csh");
    ret = MISC_system_to_buffer ("lb_rm -c /users/jing/rpg/lib/misc/*.log", NULL, -1, NULL);

    printf ("MISC_system_to_buffer ret %d\n", ret);
    MISC_system_shell (NULL);

    exit (0);
}








