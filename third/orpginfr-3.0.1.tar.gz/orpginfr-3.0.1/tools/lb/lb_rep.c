
/*****************************************************************

    File: lb_rep.c
    Description: The LB replication tool.

*****************************************************************/

/* 
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: lb_rep.c 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */  


#include <config.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#include <signal.h>


#include <infr.h>

#include <zlib.h>
#include <bzlib.h>

static int Verbose = 0;			/* verbose mode */
static char Conf_file[NAME_SIZE] = "";	/* configuration file name */

static char Byteswap_type[NAME_SIZE] = ""; /* data type name for byte swap */

#define MAX_REPS 	128		/* maximum number LBs processed */

#define COMPRESSION_NONE       0
#define COMPRESSION_ZLIB       1
#define COMPRESSION_BZIP2      2

#define MAGIC1_NUMBER       8755
#define MAGIC2_NUMBER       0427

#define PACKAGE_SIZE	    50000	/* size of multiple message package */
#define PACKAGE_MSG_CNT	    100		/* max number of messages in package */

/* Macro defintions used by the bzip2 compressor. */
#define BZIP2_MIN_BLOCK_SIZE_BYTES   100000  /* corresponds to 100 Kbytes */  
#define BZIP2_MIN_BLOCK_SIZE              1  /* corresponds to 100 Kbytes */  
#define BZIP2_MAX_BLOCK_SIZE              9  /* corresponds to 900 Kbytes */  
#define BZIP2_WORK_FACTOR                30  /* the recommended default */
#define BZIP2_NOT_VERBOSE                 0  /* turns off verbosity */
#define BZIP2_NOT_SMALL                   0  /* does not use small version */


typedef struct {

   int magic1;				/* first magic number */
   int magic2;				/* second magic number */
   char method;				/* compression method: none, zlib,
                                           or bzip2 */
   char package;			/* This is a multiple msg package */
   int len;                             /* length of the uncompressed data,
                                           not including the compression
                                           header */

} Cmp_hdr_t;

enum {PRIMARY, SHARED_SRC, UNAVAILABLE};
					/* values for Lb_rep_pair.rep */
#define TYPE_UNAVAILABLE 0xffffffff	/* the LB type is not available */

typedef struct {			/* struct registering a 
					   source/destination pair of LBs; If 
					   multiple destinations are specified,
					   multiple pairs can be used for the 
					   same source/destination LB. */
    char *src_name;			/* name of the source LB */
    char *dest_name;			/* name of the destination LB */
    unsigned int stype;			/* source LB type; The source and 
					   destination must be both replaceable
					   or both sequential; TYPE_UNAVAILABLE
					   if the LB type can not be determined
					   */
    short rep;				/* replication action:
					   PRIMARY - primary replication;
					   SHARED_SRC - share source replic.; 
					   The source is the same as a previous
					   source and both the source and 
					   destination LBs exist.
					   UNAVAILABLE - One of the 
					   destination and source LBs does not 
					   exist. */
    int src;				/* source LB file descriptor */
    int dest;				/* destination LB file descriptor */
    LB_status *status;			/* source LB status used if the LB is 
					   replaceable and stype is PRIMARY */
} Lb_rep_pair;

static Lb_rep_pair Rep_list[MAX_REPS];  /* The list of all specified 
					   replication source/destination 
					   pairs */

static int N_reps;			/* size of list Rep_list */

static int Max_static_msgs; 		/* max number of messages for static 
					   replication */
static int Static_rep_only;		/* conduct static replication only  */
static int Retry_rep_path;              /* keep retrying replication path   */

static char *Msg_buf = NULL;		/* buffer for copying messages */
static int Buf_size = 0;		/* size of Msg_buf */

static int Poll_ms;			/* milli-seconds between each poll
					   in dynamic replication */

static int Server_port = 0;		/* server (rssd) port number */

static int Single_queue_replication = 0;/* LB read polling feature used */

static int Comp_type = COMPRESSION_NONE; /* No data compression */

static int Package_time = 0;		/* max delay time (in ms) due to 
					   packing multiple messages; 0 
					   indicates no message packing */
static int Test_delay = 0;		/* Adding comms delay for testing */

static int (*Bz2BuffToBuffCompress) (char *, unsigned int *, char *, 
				unsigned int, int, int, int) = NULL;
static int (*Bz2BuffToBuffDecompress) (char *, unsigned int *, char *, 
				unsigned int, int, int) = NULL;
static int (*Zuncompress) (unsigned char *, unsigned long *, const unsigned char *, 
						unsigned long) = NULL;
static int (*Zcompress) (unsigned char *, unsigned long *, const unsigned char *, 
						unsigned long) = NULL;


/* local functions */
static int Read_options (int argc, char **argv);
static int Read_config ();
static void Conf_error (char *msg);
static int Open_lbs ();
static int Copy_name (char **dest, char *src, int len);

/* process sequential LBs */
static int Static_sequential ();
static int Allocate_buffer ();
static int Copy_msg (int need_read, int src, int dest, LB_info *info);
static void Routine_replication ();
static int Copy_single_queue_msg ();

/* process replaceable LBs */
static int Static_replaceable ();
static int Routine_replaceable (int ind);
static int Init_lb_status (int ind, LB_info **pinlist);
static int Copy_a_src_msg (int ind, LB_info *info);

/* do data compression */
static int ZLIB_compression( char *src, unsigned int src_len,
                      char **dest, unsigned int *dest_len, int package );
static int BZIP2_compression( char *src, unsigned int src_len,
                      char **dest, unsigned int *dest_len, int package );
static int Decompression( int method, char *src, unsigned int src_len,
                          char **dest, unsigned int *dest_len );

static int Write_LB( int lbd, char *buf, int len, LB_id_t msg_id );
static double Get_current_time ();
static void *Load_funcs (char *file, char *func);
static void Sig_callback (int sig);



/****************************************************************

    Description: This is the main function for lb_rep.

******************************************************************/

int main (int argc, char **argv)
{

    Max_static_msgs = 0;
    Static_rep_only = 0;
    N_reps = 0;
    Poll_ms = 500;

    /* get command line options */
    if (Read_options (argc, argv) != 0)
	exit (1);

    /* read configuration file */
    if (Read_config () != 0)
	exit (1);

    sigset (SIGPIPE, Sig_callback);

    if (Server_port > 0 &&
	RMT_port_number (Server_port) < 0) {
	MISC_log ("RMT_port_number (%d) failed\n", Server_port);
	exit (1);
    }

    if (Retry_rep_path) {
	while (1) {
	    if (Open_lbs () == 0)
		break;
	    sleep (10);			/* try again */
	}
    }
    else if (Open_lbs () != 0)
	exit (1);

    /* allocate the initial buffer */
    if (Allocate_buffer () < 0)
	exit (1);

    RMT_time_out (0x7ffffff);	/* never timed out */

    /* static replication */
    if (!Single_queue_replication) {
	if (Verbose)
	    MISC_log ("Static replication ...\n");
	if (Static_sequential () != 0 ||
	    Static_replaceable () != 0)
	    exit (1);
	if (Verbose)
	    MISC_log ("Static replication done\n");
    
	if (Static_rep_only)
	    exit (0);
    }

    /* dynamic replication */
    while (1) {
	Routine_replication ();
	if (Verbose)
	    MISC_log ("We will restart dynamic replication\n");
	sleep (5);
	Open_lbs ();
    }

    exit (0);
}

static void Sig_callback (int sig) {
    MISC_log ("Signal SIGPIPE received and ignored\n"); 
}

/*******************************************************************

    Description: This function performs the static replication for
		all sequential LBs. It copies all messages in each 
		source LB that are missing in the corresponding 
		destination LB to the latter. 

    Return:	It returns 0 on success or -1 on failure.

*******************************************************************/

static int Static_sequential ()
{
    LB_info *inlist, *outlist;
    int i, cnt;

    if (Max_static_msgs <= 0)
	return (0);

    inlist = (LB_info *)malloc (Max_static_msgs * sizeof (LB_info));
    outlist = (LB_info *)malloc (Max_static_msgs * sizeof (LB_info));
    if (inlist == NULL || outlist == NULL) {
	MISC_log ("malloc failed in Static_sequential\n");
	return (-1);
    }
    
    cnt = 0;
    for (i = 0; i < N_reps; i++) {
	int nin, nout;
	int k;

	if (Rep_list[i].rep == PRIMARY &&
	    !(Rep_list[i].stype & LB_POOL)) {

	    nin = LB_list (Rep_list[i].src, inlist, Max_static_msgs);
	    if (nin < 0) {
		MISC_log ("LB_list %s failed (ret = %d)\n", 
					Rep_list[i].src_name, nin);
		return (-1);
	    }

	    if (nin == 0)
		continue;

	    /* check all destinations */
	    for (k = i; k < N_reps; k++) {
		int m, n;

	        if (Rep_list[k].src != Rep_list[i].src ||
		    Rep_list[k].rep == UNAVAILABLE)
		    continue;

		nout = LB_list (Rep_list[k].dest, outlist, Max_static_msgs);
		if (nout < 0) {
		    MISC_log ("LB_list %s failed (ret = %d)\n", 
					Rep_list[k].dest_name, nout);
		    return (-1);
		}

		/* do the copies */
		for (m = 0; m < nin; m++) {
		    for (n = 0; n < nout; n++) {
			if (inlist[m].id == outlist[n].id &&
				inlist[m].mark == outlist[n].mark)
			    break;
		    }
		    if (n >= nout) {
			cnt += Copy_msg (1, Rep_list[i].src,
					Rep_list[k].dest, inlist + m);
			if (Verbose)
			    MISC_log ("msg (id = %d) copied from %s to %s\n", 
				inlist[m].id, Rep_list[i].src_name, 
						Rep_list[k].dest_name);
		    }
		}
	    }
	}
    }

    if (Verbose)
	MISC_log ("%d static sequential messages copied\n", cnt);

    free (inlist);
    free (outlist);
    return (0);
}

/*******************************************************************

    Description: This function copies a message.

    Inputs:	need_read - message read is needed;
		src - source LB fd;
		dest - destination LB fd;
		info - the LB info structure for the message;

    Return:	It returns 1 on success or -1 on failure.

*******************************************************************/

static int Copy_msg (int need_read, int src, int dest, LB_info *info)
{
    int len;

    if (Buf_size < info->size && Allocate_buffer () < 0)
	return (0);

    if (need_read) {
	len = LB_read (src, Msg_buf, Buf_size, info->id);
	if (len != info->size) {
	    if (len != LB_EXPIRED) {
	        MISC_log ("LB_read failed (ret = %d)\n", len);
		return (-1);
	    }
	    if (len == LB_EXPIRED)
		LB_seek (src, 0, LB_FIRST, NULL);
	    return (0);
	}
    }

    len = Write_LB (dest, Msg_buf, info->size, info->id);
    if (len < 0 ) {
	MISC_log ("LB_write failed (ret = %d)\n", len);
	return (-1);
    }

    if (info->mark != 0)
	LB_set_tag (dest, info->id, info->mark);

    return (1);
}

/*******************************************************************

    Description: This function allocates or reallocates the message 
		buffer.

    Return:	It returns 0 on success or -1 on failure.

*******************************************************************/

#define INIT_BUF_SIZE 20000	/* initial buffer size */

static int Allocate_buffer ()
{

    /* allocate the initial buffer */
    if (Buf_size == 0)
	Buf_size = INIT_BUF_SIZE;
    else
	Buf_size = Buf_size * 2;

    if (Msg_buf != NULL)
	free (Msg_buf);

    Msg_buf = malloc (Buf_size);
    if (Msg_buf == NULL) {
	MISC_log ("malloc failed\n");
	Buf_size = 0;
	return (-1);
    }

    return (0);
}

/*******************************************************************

    Description: This function copies any new messages in the source
		LB to their destination LBs. Because current RSS 
		does not support async RPC calls, we have to poll all
		source LBs.

*******************************************************************/

static void Routine_replication () {
    static int total_cnt = 0;

    while (1) {
	int i, cnt;

	cnt = 0;
	for (i = 0; i < N_reps; i++) {
	    LB_info info;
	    int ret;

	    if (Single_queue_replication) {
		ret = Copy_single_queue_msg ();
		if (ret < 0)
		    return;
		cnt += ret;
	    }

	    else if (Rep_list[i].rep == PRIMARY) {

		if (Rep_list[i].stype & LB_POOL) {
		    cnt += Routine_replaceable (i); /* process msg pool LB */
		    continue;
		}

		/* process sequential LBs */
		ret = LB_seek (Rep_list[i].src, 0, LB_CURRENT, &info);
		if (ret < 0) {
		    MISC_log ("LB_seek (%s) failed (ret = %d)\n", 
						Rep_list[i].src_name, ret);
		    return;
		}

		if (info.size <= 0)	/* new message is not available */
		    continue;

		/* copy the new message */
		ret = Copy_a_src_msg (i, &info);
		if (ret < 0)
		    return;
		cnt += ret;
	    }
	}

	total_cnt += cnt;
	if (cnt > 0 &&
	    Verbose && (total_cnt % 100) == 1)
	    MISC_log ("%d messages dynamically replicated\n", total_cnt);

	if (cnt == 0) {
	    if (Single_queue_replication)
		msleep (200);		/* we rely on LB_set_poll */
	    else
		msleep (Poll_ms);
	}
    }
}

/*******************************************************************

    Copy a message from the source to the destination when there is
    only one source, one destination and LB type is message queue.
    LB_set_poll is called in this case. Returns the number of messages
    copied.

*******************************************************************/

static int Copy_single_queue_msg () {
    static SMI_info_t *(*get_info)(char *, void *) = NULL;
    static char *type;
    char *msg;
    int len, ret, cnt;

    if (Byteswap_type[0] != '\0' && get_info == NULL) {
	char *file, *func, *p;

	p = Byteswap_type + strlen (Byteswap_type);
	cnt = 0;
	file = type = func = NULL;
	while (p > Byteswap_type) {
	    p--;
	    if (*p == ':') {
		cnt++;
		*p = '\0';
		if (cnt == 1)
		    type = p + 1;
		else if (cnt == 2)
		    func = p + 1;
	    }
	}
	if (cnt == 0)
	    type = p;
	else if (cnt == 1)
	    func = p;
	else if (cnt == 2)
	    file = p;
	if (func == NULL)
	    func = "SMI_get_info";

	get_info = (SMI_info_t *(*)(char *, void *))Load_funcs (file, func);
	SMIA_set_smi_func (get_info);
    }

    while (1) {
	len = LB_read (Rep_list[0].src, (char *)&msg, LB_ALLOC_BUF, LB_NEXT);
	if (len < 0) {
	    if (len == LB_EXPIRED) {
		MISC_log ("LB_read msg expired\n");
		LB_seek (Rep_list[0].src, 0, LB_FIRST, NULL);
		continue;
	    }
	    if (len == LB_TO_COME) {
		ret = Write_LB (Rep_list[0].dest, NULL, -1, LB_ANY);
		if (ret < 0) {
		    MISC_log ("LB_write failed (ret = %d)\n", ret);
		    return (-1);
		}
		return (0);
	    }
	    MISC_log ("LB_read failed (ret = %d)\n", len);
	    return (-1);
	}
	break;
    }
    if (len == 0)
	return (0);

    if (get_info != NULL) {
	ret = SMIA_bswap_input (type, msg, len);
	if (ret < 0) {
	    free (msg);
	    MISC_log ("SMIA_bswap_input (%s) failed (ret = %d)\n", type, ret);
	}
    }

    ret = Write_LB (Rep_list[0].dest, msg, len, LB_ANY);
    free (msg);
    if (ret < -1) {
	MISC_log ("LB_write failed (ret = %d)\n", ret);
	return (-1);
    }
    return (1);
}

/*******************************************************************

    Description: This function performs the routine replication of a 
		replaceable LB.

    Input:	ind - source LB index in the array Rep_list;

    Return:	It returns the number of messages copied on success 
		or -1 on failure.

*******************************************************************/

static int Routine_replaceable (int ind)
{
    LB_check_list *cklist;
    int n_check;
    int ret, cnt, i;

    if ((ret = LB_stat (Rep_list[ind].src, Rep_list[ind].status)) < 0) {
	MISC_log ("LB_stat %s failed (ret = %d)\n", 
					Rep_list[ind].src_name, ret);
	return (-1);
    }
    n_check = Rep_list[ind].status->n_check;

    /* process increased msgs in the LB */
    if (Rep_list[ind].status->n_msgs > n_check) {
	LB_check_list *new_list;

	/* back up the list */
	cklist = (LB_check_list *)malloc (n_check * sizeof (LB_check_list));
	if (cklist == NULL) {
	    MISC_log ("malloc failed\n");
	    return (-1);
	}
	memcpy (cklist, Rep_list[ind].status->check_list, 
					n_check * sizeof (LB_check_list));

	if (Init_lb_status (ind, NULL) < 0) {
	    free (cklist);
	    return (-1);
	}

	/* combine the results of the two LB_stat */
	new_list = Rep_list[ind].status->check_list;
	for (i = 0; i < n_check; i++) {
	    if (cklist[i].status == LB_MSG_UPDATED) {
		int m;

		for (m = 0; m < Rep_list[ind].status->n_check; m++) {
		    if (new_list[m].id == cklist[i].id)
			new_list[m].status = LB_MSG_UPDATED;
		}
	    }
	}
	free (cklist);
    }

    /* copy updated old messages and newly created messages */
    cnt = 0;
    cklist = Rep_list[ind].status->check_list;
    for (i = 0; i < Rep_list[ind].status->n_check; i++) {
	LB_info info;

	if (cklist[i].status == LB_MSG_NOCHANGE)
	    continue;

        if ((ret = LB_seek (Rep_list[ind].src, 0, cklist[i].id, &info)) < 0) {
	    MISC_log ("LB_seek failed in Routine_replaceable (ret = %d)\n", 
							ret);
	    return (-1);
	}

	/* copy the message */
	ret = Copy_a_src_msg (ind, &info);
	if (ret < 0)
	    return (-1);
	cnt += ret;
    }

    return (cnt);
}

/*******************************************************************

    Description: This function performs the static replication for
		all replaceable LBs. It copies all messages in each 
		source LB to the corresponding destination LBs. 

    Return:	It returns 0 on success or -1 on failure.

*******************************************************************/

static int Static_replaceable ()
{
    int i, cnt;
    
    cnt = 0;
    for (i = 0; i < N_reps; i++) {

	if (Rep_list[i].rep == PRIMARY &&
	    (Rep_list[i].stype & LB_POOL)) {
	    LB_info *inlist;
	    int nmsgs;
	    int m;

	    nmsgs = Init_lb_status (i, &inlist);
	    if (nmsgs < 0)
		return (-1);

	    if (nmsgs == 0)
		continue;

	    /* copy all messages */
	    for (m = 0; m < nmsgs; m++) {
		int ret = Copy_a_src_msg (i, inlist + m);
		if (ret > 0)
		    cnt += ret;
	    }
	}
    }

    if (Verbose)
	MISC_log ("%d static replaceable messages copied\n", cnt);

    return (0);
}

/*******************************************************************

    Description: This function initializes the status field in the
		Lb_rep_pair data structure for item "ind" in Rep_list.
		It calls LB_stat to start status monitoring.

    Input:	ind - index in array Rep_list.

    Output:	pinlist - returns, if non-NULL, the LB info list.

    Return:	It returns the LB info list length on success or -1 
		on failure.

*******************************************************************/

static int Init_lb_status (int ind, LB_info **pinlist)
{
    static LB_info *inlist = NULL;	/* LB info list */
    LB_status status;
    LB_check_list *cklist;
    int nmsgs, ret, k;

    /* find number of messages */
    status.attr = NULL;
    status.n_check = 0;
    ret = LB_stat (Rep_list[ind].src, &status);
    if (ret < 0) {
	MISC_log ("lb_stat %s failed (ret = %d)\n", 
					Rep_list[ind].src_name, ret);
	return (-1);
    }

    /* get LB_info list */
    if (inlist != NULL)
	free (inlist);
    inlist = (LB_info *)malloc (status.n_msgs * sizeof (LB_info));
    if (inlist == NULL) {
	MISC_log ("malloc failed in Init_lb_status\n");
	return (-1);
    }
    
    nmsgs = LB_list (Rep_list[ind].src, inlist, status.n_msgs);
    if (nmsgs < 0) {
	MISC_log ("LB_list %s failed (ret = %d)\n", 
				Rep_list[ind].src_name, nmsgs);
	return (-1);
    }

    /* set up status field for Rep_list[ind] */
    if (Rep_list[ind].status != NULL) {
	if (Rep_list[ind].status->check_list != NULL)
	    free (Rep_list[ind].status->check_list);
	free (Rep_list[ind].status);
        Rep_list[ind].status = NULL;
    }
    Rep_list[ind].status = (LB_status *)malloc (sizeof (LB_status));
    if (Rep_list[ind].status == NULL)
	return (-1);
    cklist = (LB_check_list *)malloc (nmsgs * sizeof (LB_check_list));
    if (cklist == NULL) {
	free (Rep_list[ind].status);
	Rep_list[ind].status = NULL;
	return (-1);
    }
    Rep_list[ind].status->check_list = cklist;
    for (k = 0; k < nmsgs; k++)
	cklist[k].id = inlist[k].id;
    Rep_list[ind].status->n_check = nmsgs;
    Rep_list[ind].status->attr = NULL;

    /* initially register LB_stat */
    if ((ret = LB_stat (Rep_list[ind].src, Rep_list[ind].status)) < 0) {
	MISC_log ("LB_stat %s failed (ret = %d)\n", 
					Rep_list[ind].src_name, ret);
	return (-1);
    }

    if (pinlist != NULL)
	*pinlist = inlist;

    return (nmsgs);
}

/*******************************************************************

    Description: This function copies a message from a PRIMARY source
		to all its destination LBs.

    Input:	ind - the index in Rep_list for the source LB;
		info - the message info.

    Return:	It returns the number of successful copies or -1 on 
		failure.

*******************************************************************/

static int Copy_a_src_msg (int ind, LB_info *info)
{
    int need_read, k;
    int cnt, ret;

    need_read = 1;
    cnt = 0;
    for (k = ind; k < N_reps; k++) {

	if (Rep_list[k].src != Rep_list[ind].src ||
	    Rep_list[k].rep == UNAVAILABLE)
		continue;

	ret = Copy_msg (need_read, Rep_list[ind].src, Rep_list[k].dest, info);
	if (ret < 0)
	    return (-1);
	cnt += ret;
	need_read = 0;
	if (Verbose)
	    MISC_log ("msg (id = %d) copied from %s to %s\n", 
			info->id, Rep_list[ind].src_name, 
				Rep_list[k].dest_name);
    }
    return (cnt);
}

/*******************************************************************

    Description: This function opens all LBs and builds the valid
		replication path list.

    Return:	It returns 0 on success or -1 on failure.

*******************************************************************/

static int Open_lbs ()
{
    int cnt, i;
    static int display_err = 1;

    for (i = 0; i < N_reps; i++) {
	LB_close (Rep_list[i].src);
	LB_close (Rep_list[i].dest);
    }

    cnt = 0;
    for (i = 0; i < N_reps; i++) {
	LB_status status;
	LB_attr attr;
	int good_path;
	int ret;
	int k;

	status.attr = &attr;
	status.n_check = 0;
	good_path = 1;

	/* open source LB */
	for (k = 0; k < i; k++) {	/* check shared source */
	    if (strcmp (Rep_list[k].src_name, Rep_list[i].src_name) == 0 &&
		Rep_list[k].rep == PRIMARY)
		break;
	}
	if (k >= i) {			/* a new source */
	    Rep_list[i].src = LB_open (Rep_list[i].src_name, LB_READ, NULL);
	    if (Rep_list[i].src < 0) {
		MISC_log ("LB_open %s failed (ret = %d)\n", 
				Rep_list[i].src_name, Rep_list[i].src);
		Rep_list[i].stype = (int)TYPE_UNAVAILABLE;
		good_path = 0;
	    }
	    else {
		ret = LB_stat (Rep_list[i].src, &status);
		if (ret < 0) {
		    MISC_log ("lb_stat %s failed (ret = %d)\n", 
					Rep_list[i].src_name, ret);
		    Rep_list[i].stype = TYPE_UNAVAILABLE;
		    good_path = 0;
		}
		else
		    Rep_list[i].stype = attr.types;
	    }
	}
	else {
	    Rep_list[i].stype = Rep_list[k].stype;
	    Rep_list[i].src = Rep_list[k].src;
	}

	/* check illegal replication paths */
	if (strcmp (Rep_list[i].dest_name, Rep_list[i].src_name) == 0) {
	    MISC_log ("replication to the same LB is not allowed\n");
	    return (-1);
	}
	if (i != k && 
	    strcmp (Rep_list[i].dest_name, Rep_list[k].dest_name) == 0) {
	    MISC_log ("duplicated replication pair specified\n");
	    return (-1);
	}

	/* open destination LB */
	Rep_list[i].dest = LB_open (Rep_list[i].dest_name, LB_WRITE, NULL);
	if (Rep_list[i].dest < 0) {
	    MISC_log ("LB_open %s failed (ret = %d)\n", 
				Rep_list[i].dest_name, Rep_list[i].dest);
	    good_path = 0;
	}
	else {
	    ret = LB_stat (Rep_list[i].dest, &status);
	    if (ret < 0) {
		MISC_log ("lb_stat %s failed (ret = %d)\n", 
					Rep_list[i].dest_name, ret);
		good_path = 0;
	    }
	}

	/* make sure the source and the destination have the same type */
	if (good_path &&
	    Rep_list[i].stype != TYPE_UNAVAILABLE) {
	    if ((Rep_list[i].stype & LB_POOL) == 
				(attr.types & LB_POOL)) {
		if (k < i)
		    Rep_list[i].rep = SHARED_SRC;
		else
		    Rep_list[i].rep = PRIMARY;

		cnt++;
	    }
	    else {
		MISC_log ("LBs %s and %s of different types\n", 
				Rep_list[i].src_name, Rep_list[i].dest_name);
		good_path = 0;
	    }
	}
	else 
	    good_path = 0;

	if (!good_path) {
	    Rep_list[i].rep = UNAVAILABLE;
	    if (Rep_list[i].dest >= 0)
		LB_close (Rep_list[i].dest);
	    if (k >= i && Rep_list[i].src >= 0)
		LB_close (Rep_list[i].src);
	}
    }

    if (N_reps == 1 && !(Rep_list[0].stype & LB_POOL)) {
	if (Poll_ms > 1000)
	    Poll_ms = 1000;
	LB_set_poll (Rep_list[0].src, 1, Poll_ms);
	Single_queue_replication = 1;
	if (Verbose)
	    MISC_log ("Single path message queue replication\n");
	if (Static_rep_only)
	    LB_seek (Rep_list[0].src, 0, LB_FIRST, NULL);
    }

    if (cnt > 0) {
	if (Verbose)
	    MISC_log ("%d replication pairs established\n", cnt);
	return (0);
    }
    else {
        /* keep this error from filling up the log */
        if ( (display_err % 100) == 0) {
	   MISC_log ("no replication path can be established\n");
           display_err++;
           if (display_err > 100)
              display_err = 1;
        }
	return (-1);
    }
}

/*******************************************************************

    Description: This function reads the configuration file.

    Return:	It returns 0 on success or -1 on failure.

*******************************************************************/

#define BUF_SIZE 256

static int Read_config ()
{
    char buf [BUF_SIZE];
    int len;

    if (strlen(Conf_file) == 0)
	return (0);

    CS_cfg_name (Conf_file);
    CS_error (Conf_error);
    CS_control (CS_COMMENT | '#');

    while ((len = CS_entry (CS_NEXT_LINE, 0, BUF_SIZE, buf)) > 0) {

	if (N_reps >= MAX_REPS) {
	    MISC_log ("too many LBs to be processed\n");
	    return (-1);
	}

	/* get the source name */
	if (Copy_name (&Rep_list[N_reps].src_name, buf, len) < 0)
	    return (-1);

	/* get the destination name */
	len = CS_entry (CS_THIS_LINE, 1, BUF_SIZE, buf);

	if (len <= 0) {
	    MISC_log ("error found in configuration file %s\n", Conf_file);
	    return (-1);
	}
	if (Copy_name (&Rep_list[N_reps].dest_name, buf, len) < 0)
	    return (-1);

	Rep_list[N_reps].status = NULL;
	N_reps++;
    }

    CS_control (CS_DELETE | CS_CLOSE);
    return (0);
}

/**************************************************************************

    Description: This function allocates appropriate space for pointer
		"dest" and copies the string in "src" to "dest".

    Input:	dest - pointer to the destination string;
		src - source string;
		len - string length;

    Return:	It returns 0 on success or -1 on failure.

**************************************************************************/

static int Copy_name (char **dest, char *src, int len)
{

    *dest = malloc (len + 1);
    if (*dest == NULL) {
	MISC_log ("malloc failed\n");
	return (-1);
    }
    strncpy (*dest, src, len);
    *(*dest + len) = '\0';
    return (0);
}

/***************************************************************

   Description:
      This function handles the writing of the LB message to
      the destination.  The data is decompressed/compressed
      according to command line option.

   Inputs:
      lbd - LB fd
      buf - pointer to buffer to be written
      len - length, in bytes, of "buf"
      msg_id - LB message ID to be written

   Outputs:

   Returns:
      Negative error code on error, the number of bytes written
      otherwise.
      
   Notes:

***************************************************************/
static int Write_LB( int lbd, char *buf, int len, LB_id_t msg_id ){

   int method, magic1, magic2;
   Cmp_hdr_t *hdr = NULL;
   int temp_len, dest_len, package;
   char *temp_buf = NULL, *dest_buf = NULL;
   static char *str_buf = NULL;

   method = COMPRESSION_NONE;
   package = 0;

   /* Check if buf has compression header attached. */
   if( len >= (int)sizeof(Cmp_hdr_t)){

      hdr = (Cmp_hdr_t *) buf;
      
      magic1 = ntohl( hdr->magic1 ); 
      magic2 = ntohl( hdr->magic2 ); 
   
      if( (magic1 == MAGIC1_NUMBER) && (magic2 == MAGIC2_NUMBER)) {
         method = hdr->method;
	 package = hdr->package;
      }

   }

   /* Fastrack the case where the method specified for writing is the 
      same as the method read from compression header in buffer */
   if( method == Comp_type) {
      if (len >= 0) {
	  if (Test_delay > 0)
	     msleep (Test_delay);
          return( LB_write( lbd, buf, len, msg_id) );
      }
      return (0);
   }

   /* Do all the other cases ....... */
   temp_len = len;
   if( method != COMPRESSION_NONE ){

      /* The data read is compressed, but the data written will be
         either uncompressed or use a different method. Therefore
         the data must be decompressed first. */
      if( Decompression( method, buf, (unsigned int) len, 
                         &temp_buf, &temp_len ) < 0 ){

         if( temp_buf != NULL )
            free( temp_buf );

         return(-1);

      }

   }
   else {		/* The data read was not compressed. */
      if (Comp_type == COMPRESSION_NONE || !Single_queue_replication || 
          Package_time == 0) {
         temp_len = len;
         temp_buf = buf;
      }
      else {
	 static int cnt = 0;
	 static double start;

	 if (cnt == 0) {
	    str_buf = STR_reset (str_buf, PACKAGE_SIZE);
	    start = Get_current_time ();
	 }

         /* pack the message */
	 if (len > 0) {
	    int l = htonl (len);
	    str_buf = STR_append (str_buf, (char *)&l, sizeof (int));
	    str_buf = STR_append (str_buf, buf, len);
	    cnt++;
	 }

	 if (cnt >= PACKAGE_MSG_CNT || 		/* package is full */
		STR_size (str_buf) >= PACKAGE_SIZE ||
		(cnt > 0 && Get_current_time () >= start + Package_time)) {
            temp_len = STR_size (str_buf);
            temp_buf = str_buf;
	    cnt = 0;
	    package = 1;
	    if (temp_len == 0)
		return (0);
	 }
	 else {
	    if (len < 0)
		len = 0;
	    return (len);
	 }
      }

   }
   if (temp_len < 0)
      return (0);

   /* Pre-process the data to be written according to the value
      "Comp_type" */
   dest_len = (unsigned int) temp_len;
   switch( Comp_type ){

      case COMPRESSION_ZLIB:
      {
         ZLIB_compression( temp_buf, (unsigned int) temp_len, &dest_buf, 
                           &dest_len, package );
         break;

      }

      case COMPRESSION_BZIP2:
      {
         BZIP2_compression( temp_buf, (unsigned int) temp_len, &dest_buf, 
                            &dest_len, package );
         break;

      }

      case COMPRESSION_NONE:
      {

         dest_buf = temp_buf;
         break;
       }

   /* End of "switch" */
   }

   /* Write out the data buffer. */
   if (method != COMPRESSION_NONE && 
			Comp_type == COMPRESSION_NONE && package) {
      int l;
      char *p;

      p = dest_buf;
      while (1) {
	 if (p - dest_buf == dest_len)
	    break;
	 if ((p - dest_buf) + sizeof (int) > dest_len) {
	    MISC_log ("Bad packed message (msg len missing)\n");
	    break;
	 }
	 memcpy ((char *)&l, p, sizeof (int));
	 p += sizeof (int);
	 l = ntohl (l);
	 if ((p - dest_buf) + l > dest_len) {
	    MISC_log ("Bad packed message (bad msg len)\n");
	    break;
	 }
	 if (l > 0)
	    len = LB_write( lbd, p, l, msg_id );
	 else
	    len = 0;
	 if (len < 0)
	    break;
	 p += l;
      }
   }
   else {
      len = LB_write( lbd, dest_buf, dest_len, msg_id );
      if (Test_delay > 0 && len > 0)
	  msleep (Test_delay);
   }

   /* Free all allocated buffers. */
   if( dest_buf != temp_buf && dest_buf != NULL){

      free( dest_buf );
      dest_buf = NULL;

   }

   if( temp_buf != buf && temp_buf != str_buf && temp_buf != NULL){

      free( temp_buf );
      temp_buf = NULL;

   }

   return(len);

}

/***************************************************************
   Description:
      A pointer to source buffer and size of the source buffer
      are passed.  The receiving buffer, "dest" contains the 
      compressed data.  The length of the compressed data is 
      returned in "dest_len". 

   Inputs:
      src - pointer to source
      src_len - length, in bytes, of the source
      dest - pointer to a pointer to character buffer to receive
             the compressed data  
      dest_len - pointer to int to receive the length of
                 receiving buffer.  

   Outputs:
      dest - contains the address of the destination buffer.
      dest_len - contains the length of the receiving buffer.

   Returns:
      Returns -1 on any error and 0 on success.

   Notes:

***************************************************************/
static int ZLIB_compression( char *src, unsigned int src_len,
                      char **dest, unsigned int *dest_len, int package){

   int ret;
   unsigned int len;
   unsigned long long_dest_len;

   Cmp_hdr_t *hdr = NULL;

   /* Allocate a compression scratch buffer.  The compression 
      scratch buffer should be 0.1% larger than source + 12 bytes. 
      We add an additional compression header. */
   len = src_len*1.001 + 12;
   *dest = malloc( len + sizeof(Cmp_hdr_t) );
   if( *dest == NULL ){

      MISC_log( "malloc Failed For %d Bytes\n", len );
      return( -1 );

   }

   hdr = (Cmp_hdr_t *) *dest;
   hdr->magic1 = htonl( MAGIC1_NUMBER );
   hdr->magic2 = htonl( MAGIC2_NUMBER );
   hdr->len = htonl( src_len );
   hdr->method = COMPRESSION_ZLIB;
   hdr->package = package;

   if (Zcompress == NULL)
      Load_funcs ("gzip", NULL);

   /* Do the zlib compression. */
   long_dest_len = (unsigned long) len;
   ret = Zcompress( *dest + sizeof(Cmp_hdr_t), &long_dest_len, 
                   src, (unsigned long) src_len );

   /* If the compression fails, just hand back the source 
      buffer. */
   if( ret != Z_OK ){

      MISC_log( "ZLIB Compression Failed (%d)\n", ret );

      hdr->method = COMPRESSION_NONE;
      memcpy( dest + sizeof(Cmp_hdr_t), src, src_len );
      *dest_len = src_len + sizeof(Cmp_hdr_t);

   }
   else
      *dest_len = ((unsigned int) long_dest_len) + sizeof(Cmp_hdr_t);

   return( 0 );

}

/*****************************************************************
   Description:
      Decompresses the data in "src" using method "method".

   Inputs:
      method - decompression method
      src - source buffer containing compressed data.
      src_len - length, in bytes, of "src".

   Outputs:
      dest - pointer to char pointer where decompressed data is 
             placed.
      dest_len - pointer to int storing the number of bytes in
                 decompressed buffer.

   Returns:
      Negative error code on error, 0 otherwise.

   Notes:

*****************************************************************/
static int Decompression( int method, char *src, unsigned int src_len,
                          char **dest, unsigned int *dest_len ){
   
   int ret;

   Cmp_hdr_t *hdr = (Cmp_hdr_t *) src; 
   char *msg = src + sizeof(Cmp_hdr_t);
   
   /* Allocate a decompression buffer the same size as the 
      original data. */
   *dest_len = ntohl( hdr->len );
   *dest = malloc( *dest_len );
   if( *dest == NULL ){

      MISC_log( "malloc Failed For %d Bytes\n", *dest_len );
      return( -1 );
   
   }

   /* Account for the compression header when passing source
      size to decompressor. */
   src_len = src_len - sizeof(Cmp_hdr_t);
 
   /* Decompress the buffer contents ...... */
   switch( method ){

      case COMPRESSION_BZIP2:
      {

         if (Bz2BuffToBuffDecompress == NULL)
             Load_funcs ("bzip2", NULL);
         ret = Bz2BuffToBuffDecompress( *dest, dest_len, msg, 
                                           (unsigned int) src_len,
                                           BZIP2_NOT_SMALL, 
                                           BZIP2_NOT_VERBOSE );

         if( ret != BZ_OK ){

            MISC_log( "BZIP2 Decompression Failed: %d\n", ret );
            return(-1);

         }
         break;

      }

      case COMPRESSION_ZLIB:
      {

         unsigned long long_dest_len = (unsigned long) *dest_len;
	 if (Zuncompress == NULL)
            Load_funcs ("gzip", NULL);
         ret = Zuncompress( *dest, &long_dest_len, msg, (unsigned long) src_len );

         if( ret != Z_OK ){

            MISC_log( "ZLIB Decompression Failed: %d\n", ret );
            return(-1);

         }

         *dest_len = (unsigned int) long_dest_len;
      
         break;

      }

   /* End of "switch" */
   }

   return( 0 );

}

/*******************************************************************

    Loads shared library funcition "func" in file "file" and  returns
    the function pointer. Terminates the process on failure. It loads
    functions for bzip2 and gzip respectively if file is "bzip2" or
    "gzip" respectively. The return value is not used in these cases.

*******************************************************************/

static void *Load_funcs (char *file, char *func) {
    void *handle, *p;
    char *error, *libbz2, *libz;

#ifdef LINK_STATIC_LIB
    if (strcmp (file, "bzip2") == 0) {
	Bz2BuffToBuffCompress = BZ2_bzBuffToBuffCompress;
	Bz2BuffToBuffDecompress = BZ2_bzBuffToBuffDecompress;
	return (NULL);
    }
    else if (strcmp (file, "gzip") == 0) {
	Zuncompress = uncompress;
	Zcompress = compress;
	return (NULL);
    }
#endif

    libbz2 = "libbzip2.so";
    libz = "libz.so";
    if (strcmp (file, "bzip2") == 0)
	file = libbz2;
    else if (strcmp (file, "gzip") == 0)
	file = libz;

    if ((handle = dlopen (file, RTLD_LAZY)) == NULL) {
	MISC_log ("%s\n", dlerror ());
	exit (1);
    }

    p = NULL;
    if (strcmp (file, libbz2) == 0) {
	func = "BZ2_bzBuffToBuffCompress";
	Bz2BuffToBuffCompress = (int (*)())dlsym (handle, func);
	if (Bz2BuffToBuffCompress != NULL) {
	    func = "BZ2_bzBuffToBuffDecompress";
	    Bz2BuffToBuffDecompress = (int (*)())dlsym (handle, func);
	}
    }
    else if (strcmp (file, libz) == 0) {
	func = "uncompress";
	Zuncompress = (int (*)())dlsym (handle, func);
	if (Zuncompress != NULL) {
	    func = "compress";
	    Zcompress = (int (*)())dlsym (handle, func);
	}
    }
    else {
	p = dlsym (handle, func);
    }

    if ((error = dlerror()) != NULL) {
	MISC_log ("%s - %s\n", error, func);
	exit (1);
    }
    return (p);
}

/***************************************************************
   Description:
      A pointer to source buffer and the size of the source
      buffer are passed.  The receiving buffer, "dest" contains
      the entire compressed data.  The length of the compressed
      data is returned in "dest_len". 

   Inputs:
      src - pointer to source buffer.
      src_len - length, in bytes, of the source buffer.
      dest - pointer to a pointer to character buffer to receive
             the compressed data.  
      dest_len - pointer to int to receive the length of
                 receiving buffer.  

   Outputs:
      dest - contains the address of the destination buffer.
      dest_len - contains the length of the receiving buffer.

   Returns:
      Returns -1 on any error and 0 on success.

   Notes:

***************************************************************/
static int BZIP2_compression( char *src, unsigned int src_len,
                     char **dest, unsigned int *dest_len, int package ){

   int ret, block_size;
   Cmp_hdr_t *hdr = NULL;

   if (Bz2BuffToBuffCompress == NULL)
      Load_funcs ("bzip2", NULL);

   /* Allocate a compression scratch buffer the same size as the
      original data plus the compression header. */
   *dest = malloc( src_len + sizeof(Cmp_hdr_t) );
   if( *dest == NULL ){

      MISC_log( "malloc Failed For %d Bytes\n", src_len + sizeof(Cmp_hdr_t) );
      return( -1 );

   }

   /* Determine what block size to use ... try and fit entire data is one
      block. */
   block_size = (src_len/BZIP2_MIN_BLOCK_SIZE_BYTES) + 1;
   if( block_size < BZIP2_MIN_BLOCK_SIZE )
      block_size = BZIP2_MIN_BLOCK_SIZE;
   else if( block_size > BZIP2_MAX_BLOCK_SIZE )
      block_size = BZIP2_MAX_BLOCK_SIZE;

   hdr = (Cmp_hdr_t *) *dest;
   hdr->magic1 = htonl( MAGIC1_NUMBER );
   hdr->magic2 = htonl( MAGIC2_NUMBER );
   hdr->len = htonl( src_len );
   hdr->method = COMPRESSION_BZIP2;
   hdr->package = package;

   /* Do the bzip2 compression. */
   ret = Bz2BuffToBuffCompress( *dest + sizeof(Cmp_hdr_t), dest_len, src, 
                                   src_len, block_size, BZIP2_NOT_VERBOSE,
                                   BZIP2_WORK_FACTOR );

   /* Process Non-Normal return. */
   if( ret != BZ_OK ){

      MISC_log( "BZIP2 Compression Failed (%d)\n", ret );
       
      hdr->method = COMPRESSION_NONE;
      memcpy( dest + sizeof(Cmp_hdr_t), src, src_len );
      *dest_len = src_len + sizeof(Cmp_hdr_t);

   }
   else
      *dest_len += sizeof(Cmp_hdr_t);

   return( 0 );

}

/******************************************************************

    Returns the current clock time in ms.

******************************************************************/

static double Get_current_time () {
    struct timeval cur_time;

    gettimeofday (&cur_time, NULL);
    return ((double)cur_time.tv_sec * 1000 + cur_time.tv_usec * .001);
}

/**************************************************************************

    Description: This function prints error messages while reading the link 
		configuration file.

    Return:	It returns 0 on success or -1 on failure.

**************************************************************************/

static void Conf_error (char *msg)
{

    MISC_log (msg);
}

/*******************************************************************

    Description: This function interprets command line arguments.

    Inputs:	argc - number of command arguments
		argv - the list of command arguments

    Return:	It returns 0 on success or -1 on failure.

*******************************************************************/

static int Read_options (int argc, char **argv)
{
    extern char *optarg;    /* used by getopt */
    extern int optind;      /* used by getopt */
    int c;            
    int err;                /* error flag */

    err = 0;
    while ((c = getopt (argc, argv, "n:r:c:p:t:e:sxC:d:vh?")) != EOF) {
	switch (c) {
	    int off;

	    case 'n':
		if (sscanf (optarg, "%d", &Max_static_msgs) != 1)
		    err = 1;
		break;

	    case 'p':
		if (sscanf (optarg, "%d", &Poll_ms) != 1)
		    err = 1;
		break;

	    case 'c':
		if (sscanf (optarg, "%d", &Server_port) != 1)
		    err = 1;
		break;

	    case 't':
		strncpy (Byteswap_type, optarg, NAME_SIZE);
		Byteswap_type[NAME_SIZE - 1] = '\0';
		break;

	    case 's':
		Static_rep_only = 1;
		break;

	    case 'x':
		Retry_rep_path = 1;
		break;

	    case 'r':
		off = 0;
		while (optarg[off] != '\0' && optarg[off] != ',')
		    off++;
		if (optarg[off] != ',') {
		    off = 0;
		    while (optarg[off] != '\0' && optarg[off] != '-')
			off++;
		}
		if (optarg[off] == '\0') {
		    MISC_log ("bad argument in -r option (%s)\n", optarg);
		    err = 1;
		}
		else {
		    if (Copy_name (&Rep_list[N_reps].src_name, 
							optarg, off) < 0 ||
		        Copy_name (&Rep_list[N_reps].dest_name, 
			    optarg + off + 1, strlen (optarg) - off - 1) < 0 ||
			strlen (Rep_list[N_reps].src_name) == 0 ||
			strlen (Rep_list[N_reps].dest_name) == 0) {
			MISC_log ("bad argument in -r option (%s)\n", 
							optarg);
		        err = 1;
		    }
		    else
			N_reps++;
		}
		break;

            case 'C':
		if (sscanf (optarg, "%d", &Comp_type) != 1)
		    err = 1;

                if( (Comp_type < COMPRESSION_NONE) 
                               &&
                    (Comp_type > COMPRESSION_BZIP2) ){

                   MISC_log("bad argument in -C option (%s)\n", optarg );
                   err = 1;

                }
                break;

            case 'd':
		if (sscanf (optarg, "%d", &Package_time) != 1)
		    err = 1;
                break;

	    case 'e':
		if (sscanf (optarg, "%d", &Test_delay) != 1)
		    err = 1;
		break;

	    case 'v':
		Verbose = 1;
		break;

	    case 'h':
	    case '?':
		err = 1;
		break;
	    default:
		MISC_log ("Unexpected option (-%c)\n", c);
		err = 1;
		break;
	}
    }

    if (optind == argc - 1) {       /* get the input LB name  */
	strncpy (Conf_file, argv[optind], NAME_SIZE);
	Conf_file [NAME_SIZE - 1] = '\0';
    }

    if (N_reps == 0 && err == 0 && strlen (Conf_file) == 0) {
	MISC_log ("no replication path specified\n");
	err = 1;
    }

    if (err == 1) {              /* Print usage message */
	printf ("Usage: %s options conf_file_name\n", argv[0]);
	printf ("       options: \n");
	printf ("       -r src_lb_name,dest_lb_name (Multiple -r options\n");
	printf ("          are fine. '-' can be used to replace ',')\n");
	printf ("       -t lib_file:func_name:byteswap_type (type name for byte swap)\n");
	printf ("       -c server_port_number\n");
	printf ("       -n max_static_msg_number (maximum number of \n");
	printf ("          messages staticly replicated; The default is 0;\n");
	printf ("          This applies to sequential LB only)\n");
	printf ("       -s (static replication only mode)\n");
	printf ("       -x (do not exit -retry replication path forever)\n");
	printf ("       -p poll_ms (milli-seconds between each poll in dynamic replication)\n");
	printf ("          The default is 500 ms (.5 second)\n");
        printf ("       -C cmp_method for output (0 = None, 1 = zlib or 2 = bzip2)\n"); 
        printf ("          The default is 0 (None)\n" );
        printf ("       -d Package_time (maximum delay time (in ms) due to packing\n"); 
        printf ("          multiple messages. The default is 0 (no message packing)\n" );
	printf ("       -e ms (adds delay of ms for each message for testing)\n");
	printf ("       -v (verbose mode)\n");
	return (-1);
    }

    return (0);
}
