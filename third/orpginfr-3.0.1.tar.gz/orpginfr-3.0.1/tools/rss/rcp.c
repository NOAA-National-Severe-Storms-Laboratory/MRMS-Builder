
/******************************************************************
	file: rcp.c
	Remote file copy.
******************************************************************/

/* 
 * RCS info
 * $Author: charles $
 * $Locker$
 * $Date: 2004-02-20 14:18:15 -0600 (Fri, 20 Feb 2004) $
 * $Id: rcp.c 121 2004-02-20 20:18:15Z charles $
 * $Revision: 121 $
 * $State$
 */  


#include <config.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#ifdef LITTLE_ENDIAN_MACHINE
#include <netinet/in.h>
#endif
#include <infr.h>

#define RCP_NAME_SIZE 128

static char Local_host[RCP_NAME_SIZE];
static unsigned int Local_ip;

static int Copy_a_file (char *src, char *dest);
void Get_host_and_file_name (char *name, char *host, char *fname);
static void Get_dname (char *dest, char *dname);
static void Add_file_name_to_dest (char *fname, char *dest, char *full_name);

/*****************************************************************************

*****************************************************************************/

int main (int argc, char **argv)
{
    int i, n;
    unsigned int *add;

    if (argc < 3) {
	printf ("Too few arguments: rcp src dest\n");
	exit (1);
    }

    n = NET_find_local_ip_address (&add);
    for (i = 0; i < n; i++) {		/* search for the ppp connection */
	if ((add[i] & 0xffff) == 0xf81) {
	    Local_ip = add[i];
	    break;
	}
    }
    if (i >= n) {
	if (n > 0)
	     Local_ip = add[0];
	else {
	    printf ("NET_find_local_ip_address failed\n");
	    exit (1);
	}
    }
#ifdef LITTLE_ENDIAN_MACHINE
    Local_ip = ntohl (Local_ip);
#endif

    if (gethostname (Local_host, RCP_NAME_SIZE) < 0) {
	printf ("gethostname failed\n");
	exit (1);
    }

/*    RMT_time_out (7200); */
    RMT_lock_connection (RMT_GLOBAL_LOCK);
    for (i = 1; i < argc - 1; i++) {
	Copy_a_file (argv[i], argv[argc - 1]);
    }
    exit (0);
}

/******************************************************************************

******************************************************************************/

static int Copy_a_file (char *src, char *dest) {
    char host[RCP_NAME_SIZE], fname[RCP_NAME_SIZE], dname[RCP_NAME_SIZE];
    char buf[RCP_NAME_SIZE * 3 + 32], full_name[RCP_NAME_SIZE];
    int ret;

/*    printf ("copy %s to %s\n", src, dest); */
    Get_host_and_file_name (src, host, fname);
    if (host[0] == '\0') {
	Add_file_name_to_dest (fname, dest, full_name);
	printf ("RSS_copy %s %s\n", fname, full_name);
	ret = RSS_copy (fname, full_name);
	if (ret < 0) {
	    printf ("RSS_copy failed (ret %d)\n", ret);
	    return (-1);
	}
    }
    else {
	int ret, r, n_bytes;
	char tbuf[1024], func[128];

	printf ("run rcp on %s\n", host);
	Get_dname (dest, dname);
	sprintf (buf, "csh -c \"rcp %s %s\"", fname, dname);
	sprintf (func, "%s:MISC_system_to_buffer", host);
	RMT_time_out (1000000);
	ret = RSS_rpc (func, "i-r s ba-256-o i ia-o", 
				&r, buf, tbuf, 256, &n_bytes);
	if (ret < 0) {
	    printf ("RSS_rpc failed ret %d\n", ret);
	    return (-1);
	}
	if (r < 0) {
	    printf ("MISC_system_to_buffer failed ret %d\n", r);
	    return (-1);
	}
	if (n_bytes >= 248)
	    strcpy (tbuf + 248, " ...\n");
	printf ("%s", tbuf);
    }
    return (0);
}

/******************************************************************************

    Returns the host part and file part in "name" in "host" and "fname". If
    the host name is local, empty "host" string is returned.

******************************************************************************/

void Get_host_and_file_name (char *name, char *host, char *fname) {
    char *cpt;

    cpt = name;
    while (*cpt != '\0') {
	if (*cpt == ':')
	    break;
	cpt++;
    }
    if (*cpt == '\0') {
	host[0] = '\0';
	strncpy (fname, name, RCP_NAME_SIZE);
	fname[RCP_NAME_SIZE - 1] = '\0';
    }
    else {
	*cpt = '\0';
	if (strcmp (name, Local_host) == 0) {
	    host[0] = '\0';
	    strncpy (fname, cpt + 1, RCP_NAME_SIZE);
	    fname[RCP_NAME_SIZE - 1] = '\0';
	}
	else {
	    strncpy (host, name, RCP_NAME_SIZE);
	    fname[RCP_NAME_SIZE - 1] = '\0';
	    strncpy (fname, cpt + 1, RCP_NAME_SIZE);
	    fname[RCP_NAME_SIZE - 1] = '\0';
	}
	*cpt = ':';
    }
}

/*****************************************************************************

    Generate destination name for remote rcp. If "dest" does not have a host
    name part, local host is added.

*****************************************************************************/

static void Get_dname (char *dest, char *dname) {
    char *cpt;

    cpt = dest;
    while (*cpt != '\0') {
	if (*cpt == ':')
	    break;
	cpt++;
    }
    if (*cpt == '\0') {
	sprintf (dname, "%d.%d.%d.%d:", 
		Local_ip >> 24, (Local_ip >> 16) & 0xff, 
		(Local_ip >> 8) & 0xff, Local_ip & 0xff);
	if (dest[0] == '.') {
	    char *pwd = getenv ("PWD");
	    if (pwd != NULL) {
		strncat (dname, pwd, RCP_NAME_SIZE - strlen (dname) - 1);
		dname[RCP_NAME_SIZE - 2] = '\0';
		strcat (dname, "/");
		dest++;
	    }
	}
	strncat (dname, dest, RCP_NAME_SIZE - strlen (dname));
	dname[RCP_NAME_SIZE - 1] = '\0';
    }
    else {
	strncpy (dname, dest, RCP_NAME_SIZE);
	dname[RCP_NAME_SIZE - 1] = '\0';
    }
}

/*****************************************************************************

    Finds file name part in "fname" and adds it to "dest" and puts in 
    "full_name".

*****************************************************************************/

static void Add_file_name_to_dest (char *fname, char *dest, char *full_name) {
    char *cpt;

    cpt = fname + strlen (fname) - 1;
    while (cpt >= fname) {
	if (*cpt == '/')
	    break;
	cpt--;
    }
    cpt++;
    strncpy (full_name, dest, RCP_NAME_SIZE - 1);
    full_name[RCP_NAME_SIZE - 2] = '\0';
    if (full_name[strlen (full_name) - 1] != '/')
	strcat (full_name, "/");
    strncat (full_name, cpt, RCP_NAME_SIZE - strlen (full_name));
    full_name[RCP_NAME_SIZE - 1] = '\0';
}









