
/******************************************************************

	This is the main module for the sdmqm program - the Simple 
	Data Base Query Manager.
	
******************************************************************/
/*
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: sdqs_main.c 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */


#include <config.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include <infr.h> 

#include "sdqs_def.h"


#define SDQS_NAME_SIZE 128

static char *Prog_name;				/* name of this program */
static char Conf_name[SDQS_NAME_SIZE] = "";	/* config file name */
static char Environ_name[SDQS_NAME_SIZE] = "";	/* environment name */
static char Shared_lib_name[SDQS_NAME_SIZE] = "sdqs";
						/* shared library name */
int Verbose;					/* verbose mode */
static int Log_size = 300;			/* size of the log file */
static int No_compilation;			/* run without compilation */
static int Display_on_stderr;			/* also print msgs on stderr */
static int Compile_only;			/* terminate after compiling */
static char Port_number[SDQS_NAME_SIZE] = "60245"; /* query port number */

static int In_termination_phase = 0;

/* local functions */
static void Print_cs_error (char *msg);
static void Print_usage (char **argv);
static int Read_options (int argc, char **argv);
static void Signal_handler (int sig);
static int Process_client_request (char *req, int req_len, char **resp);
static int House_keeping ();
static void Ntf_fd_ready (int fd, int ready_flag);
static void Redirect_to_le (char *msg);


/******************************************************************

    Description: The main function.

******************************************************************/

int main (int argc, char **argv) {
    int ret;
    char addr[64];

    LB_NTF_control (LB_NTF_SIGNAL, LB_NTF_NO_SIGNAL);

    /* read options */
    if (Read_options (argc, argv) != 0)
	exit (1);
    Prog_name = argv[0];

    /* Initialize the LE and CS services */
    if (Verbose)
	LE_local_vl (3);
    if (Log_size > 0) {
	ret = LE_create_lb (argv[0], Log_size, LB_SINGLE_WRITER, -1);
	if (ret < 0) {
	    LE_send_msg (GL_ERROR, "LE_create_lb failed (ret %d)", ret);
	    exit (1);
	}
	ret = LE_init (argc, argv);
	if (ret < 0) {
	    LE_send_msg (GL_ERROR, "LE_init failed (ret %d)", ret);
	    exit (1);
	}
    }
    CS_error (Print_cs_error);	/* asking CS to print error via 
				   Print_cs_error */
    MISC_log_reg_callback (Redirect_to_le);
    if (Display_on_stderr)
	LE_also_print_stderr (1);

    sigset (SIGTERM, Signal_handler); 
    sigset (SIGHUP, Signal_handler);
    sigset (SIGINT, Signal_handler); 
    sigignore (SIGPIPE);

    if (!No_compilation) {
	SDQSC_read_conf_file (Conf_name);
	SDQSC_generate_code ();
    }
    if (Compile_only)
	exit (0);
    SDQSO_init (No_compilation);

    /* the main loop */
    if ((ret = CSS_add_poll_fd (LB_NTF_control (LB_GET_NTF_FD), 
				POLL_IN_FLAGS, Ntf_fd_ready)) < 0) {
	LE_send_msg (GL_ERROR, "CSS_add_poll_fd failed (ret %d)", ret);
	exit (1);
    }
    sprintf (addr, "%d", SDQSO_get_css_port ());
    CSS_sv_main (addr, MAXN_CONNS, 2, Process_client_request, House_keeping);

    exit (0);
}

/**************************************************************************

    Redirects the libinfr error message to LE.

**************************************************************************/

static void Redirect_to_le (char *msg) {
    LE_send_msg (0, "%s", msg);
}

/**************************************************************************

    Returns Environ_name.

**************************************************************************/

char *SDQSM_get_environ_name () {
    return (Environ_name);
}

/**************************************************************************

    Returns DL library base name.

**************************************************************************/

char *SDQSM_get_shared_lib_basename () {
    static char *tmp = NULL;
    if (tmp == NULL) {
	tmp = SDQSM_malloc (strlen (Shared_lib_name) + 
					strlen (SDQSM_get_port ()) + 16);
	sprintf (tmp, "%s_%s", Shared_lib_name, SDQSM_get_port ());
    }
    return (tmp);
}

/**************************************************************************

    Returns DL library name.

**************************************************************************/

char *SDQSM_get_shared_lib_name () {
    static char *tmp = NULL;
    if (tmp == NULL) {
	tmp = SDQSM_malloc (strlen (Shared_lib_name) + 
					strlen (SDQSM_get_port ()) + 16);
	sprintf (tmp, "lib%s_%s.so", Shared_lib_name, SDQSM_get_port ());
    }
    return (tmp);
}

/**************************************************************************

    Returns SMI_get_info function name.

**************************************************************************/

char *SDQSM_get_smi_func_name () {
    static char *tmp = NULL;
    if (tmp == NULL) {
	tmp = SDQSM_malloc (strlen (Shared_lib_name) + 
					strlen (SDQSM_get_port ()) + 32);
	sprintf (tmp, "SDQS_SMI_get_info_%s_%s", 
				Shared_lib_name, SDQSM_get_port ());
    }
    return (tmp);
}

/**************************************************************************

    Sets the query port number.

**************************************************************************/

void SDQSM_set_port_number (char *port) {
    strncpy (Port_number, port, SDQS_NAME_SIZE);
    Port_number[SDQS_NAME_SIZE - 1] = '\0';
    return;
}

/******************************************************************

    Returns the query port number.

******************************************************************/

char *SDQSM_get_port () {
    return (Port_number);
}

/**************************************************************************

    This is called when there is an event ready to receive.

**************************************************************************/

static void Ntf_fd_ready (int fd, int ready_flag) {
    LB_NTF_control (LB_NTF_WAIT, 0);
}

/**************************************************************************

    Memory allocation of size "size".

**************************************************************************/

char *SDQSM_malloc (int size) {
    char *p;
    p = malloc (size);
    if (p == NULL)
	LE_send_msg (GL_ERROR, "malloc (size %d) failed\n", size);
    return (p);
}

/******************************************************************

    Terminations handler - called by termination signal.

******************************************************************/

static void Signal_handler (int sig) {

    LE_send_msg (GL_INFO, "Signal %d received", sig);
    In_termination_phase = 1;
    return;
}

/******************************************************************

    Description: This is the basic client request processing function.

    Inputs:	req - the request message;
		req_len - length of the request message;

    Output:	resp - returns the response message.

    Return:	length of the response message.

******************************************************************/

static int Process_client_request (char *req, int req_len, char **resp) {
    int ret;
    void *r;

    r = NULL;
    if (strncmp (req, "Select: ", 8) == 0) {
	char *lb_name, *t;
	int mode, max_n, is_big_endian;

	if ((t = strtok (req, " \t\n")) == NULL ||
	    (lb_name = strtok (NULL, " \t\n")) == NULL ||
	    (t = strtok (NULL, " \t\n")) == NULL ||
	    sscanf (t, "%d", &mode) != 1 ||
	    (t = strtok (NULL, " \t\n")) == NULL ||
	    sscanf (t, "%d", &is_big_endian) != 1 ||
	    (t = strtok (NULL, " \t\n")) == NULL ||
	    sscanf (t, "%d", &max_n) != 1)
	    return (SDQ_REQ_SYNT_ERROR);
	t += strlen (t) + 1;
	while (*t == ' ' || *t == '\t')
	    t++;
	LB_NTF_control (LB_NTF_BLOCK);
	ret = SDQS_select (lb_name, mode, max_n, is_big_endian, t, &r);
	LB_NTF_control (LB_NTF_UNBLOCK);
	if (ret <= 0) {
	    static SDQM_query_results err_res;
	    err_res.msg_size = sizeof (SDQM_query_results);
	    err_res.type = SDQM_QUERY;
	    err_res.n_recs = 0;
	    err_res.err_code = -ret;
	    *resp = (char *)&err_res;
	    LE_send_msg (LE_VL1, "SDQS_select failed (ret %d)", ret);
	    return (err_res.msg_size);
	}
    }
    else {
	LB_NTF_control (LB_NTF_BLOCK);
	ret = SDQM_process_query (req, req_len, 
				SDQM_SERIALIZED_RESULT, &r);
	LB_NTF_control (LB_NTF_UNBLOCK);
	if (ret <= 0)
	    LE_send_msg (LE_VL1, "SDQM_process_query failed (ret %d)", ret);
    }
    *resp = (char *)r;
    return (ret);
}

/******************************************************************

    Description: This is the basic server housekeeping function.
		It is called periodically.

    Return:	return value is not used.

******************************************************************/

static int House_keeping () {

    SDQSO_house_keep (In_termination_phase);
    if (In_termination_phase) {
	LE_send_msg (GL_INFO, "%s terminates", Prog_name);
	exit (0);
    }
    return (0);
}

/**************************************************************************

    Description: This function reads command line arguments.

    Inputs:	argc - number of command arguments
		argv - the list of command arguments

    Return:	It returns 0 on success or -1 on failure.

**************************************************************************/

static int Read_options (int argc, char **argv)
{
    extern char *optarg;	/* used by getopt */
/*    extern int optind; */
    int c;			/* used by getopt */
    int err;           		/* error flag */

    Verbose = Display_on_stderr = Compile_only = 0;
    No_compilation = 1;
    err = 0;
    while ((c = getopt (argc, argv, "hc:e:s:p:vdo?")) != EOF) {
	switch (c) {

	    case 'c':
		strncpy (Conf_name, optarg, SDQS_NAME_SIZE);
		Conf_name[SDQS_NAME_SIZE - 1] = '\0';
		No_compilation = 0;
		break;

	    case 'e':
		strncpy (Environ_name, optarg, SDQS_NAME_SIZE);
		Environ_name[SDQS_NAME_SIZE - 1] = '\0';
		break;

	    case 's':
		strncpy (Shared_lib_name, optarg, SDQS_NAME_SIZE);
		Shared_lib_name[SDQS_NAME_SIZE - 1] = '\0';
		break;

	    case 'p':
		strncpy (Port_number, optarg, SDQS_NAME_SIZE);
		Port_number[SDQS_NAME_SIZE - 1] = '\0';
		break;

	    case 'd':
		Display_on_stderr = 1;
		break;

	    case 'o':
		Compile_only = 1;
		Log_size = 0;
		break;

	    case 'v':
		Verbose = 1;
		break;

	    case 'h':
	    case '?':
		Print_usage (argv);
		break;
	}
    }

    return (err);
}

/**************************************************************************

    Description: This function prints the usage info.

**************************************************************************/

static void Print_usage (char **argv)
{
    printf ("Usage: %s (options)\n", argv[0]);
    printf ("       %s - the simple data base query server\n", argv[0]);
    printf ("       Options:\n");
    printf ("       -c configuration_file_name (The default is running\n");
    printf ("          without compilation)\n");
    printf ("       -e environ_name (The default is non)\n");
    printf ("       -s shared_lib_name (The default is sdqs)\n");
    printf ("       -p port_number (Used if running without compilation.\n");
    printf ("          The default is 60245)\n");
    printf ("       -o (Compilation only)\n");
    printf ("       -v (Turns on verbose mode)\n");
    printf ("       -d (Displays messages on stderr also)\n");
    printf ("       -h (Prints usage info and terminates)\n");
    exit (1);
}

/**************************************************************************

    Description: This function sends error messages while reading the link 
		configuration file.

    Return:	It returns 0 on success or -1 on failure.

**************************************************************************/

static void Print_cs_error (char *msg) {

    LE_send_msg (GL_ERROR, msg);
}


