
/*******************************************************************

    Module: le_def.h

    Description: The private header file for the LE module.

*******************************************************************/

/* 
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: le_def.h 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */  

#ifndef LE_DEF_H
#define LE_DEF_H

#define DEFAULT_LB_SIZE 300
#define DEFAULT_LB_TYPE 0

#define UNDEFINED_LB_SIZE -1
#define UNDEFINED_LB_TYPE -1

/* private functions */
void LE_save_message (char *msg);
char *LE_get_saved_msg ();
int LE_get_instance ();
char *LE_get_label ();
int LE_check_and_open_lb (char *arg0);
int LE_set_disable (int yes);


#endif 		/* #ifndef LE_DEF_H */
