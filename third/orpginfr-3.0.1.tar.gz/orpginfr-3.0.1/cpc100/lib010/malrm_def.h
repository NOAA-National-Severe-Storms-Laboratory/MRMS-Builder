/**************************************************************************

      Module: malrm_def.h

 Description: Event Notification Services (MALRM) library private
        include file (*not* for users!).

 Assumptions:

 **************************************************************************/

/*
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2004-05-06 10:57:10 -0500 (Thu, 06 May 2004) $
 * $Id: malrm_def.h 136 2004-05-06 15:57:10Z lsong $
 * $Revision: 136 $
 * $State$
 */

#ifndef MALRM_DEF_H
#define MALRM_DEF_H


/*** DO NOT REMOVE ***/
#endif
/*** DO NOT REMOVE ***/
