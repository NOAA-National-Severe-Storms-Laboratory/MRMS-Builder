/**************************************************************************
  
      Module:  malrm_lib.c
  
 Description:
	This file provides four Multiple Alarm Services (MALRM)
    	library routines: MALRM_cancel(), MALRM_deregister(),
        MALRM_register(), and MALRM_set().

	The scope of all other routines defined within this file is limited
        to this file.  The private functions are defined in alphabetical
        order, following the definitions of the API functions (which also
        appear in alphabetical order).

	Note that a Unit Test (UT) driver has been provided at the bottom of
	this file.  To compile this source file into a UT binary, compile the
	file with UTMAIN defined and link-in the required object files
	(currently only malrm_libreg.o is required).  As problems are
	discovered, and/or as new test cases are defined (in the SDF), this
	UT driver must be updated.

Interruptible System Calls:
	none

 Memory Allocation:

	none

 Notes:
        Zero is not a valid alarm ID.

	We protect the MALRM database by enclosing the body of each API
	function between calls to alarm().  The first call cancels all
	alarm() requests, and the final call resets the alarm().
  
 Assumptions:
  	(1) the signal corresponding to MALRM_ALARM_SIG is reserved for
		the use of the MALRM library
  
 **************************************************************************/

/*
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2004-05-06 10:57:10 -0500 (Thu, 06 May 2004) $
 * $Id: malrm_lib.c 136 2004-05-06 15:57:10Z lsong $
 * $Revision: 136 $
 * $State$
 */

/*
 * System Include Files/Local Include Files
 *
 */
#include <config.h>
#include <unistd.h>

#define MALRM_LIB
#include <malrm_globals.h>
#undef MALRMEN_LIB

/*
 * Constant Definitions/Macro Definitions/Type Definitions
 */

/*
 * Static Globals
 */

/*
 * Static Function Prototypes
 */
static void alarm_handler(void) ;


/**************************************************************************
 Description: Cancel a given (registered) MALRM alarm
       Input: alarm id, pointer to storage for remaining number of seconds
      Output:
              remaining seconds placed in storage pointed to by second arg
     Returns: zero upon success, or one of the following negative error codes:

                MALRM_BAD_ALARMID
		MALRM_ALARM_NOT_REGISTERED 	(malrmlr_cancel())
		MALRM_ALARM_NOT_SET 		(malrmlr_cancel())

       Notes:
 **************************************************************************/
int MALRM_cancel(malrm_id_t alarmid, unsigned int *remaining_secs)
{

   time_t current_time ;
   int retval ;

   if (alarmid == 0) {
      return(MALRM_BAD_ALARMID) ;
   }

   /*
    * Cancel the previous system alarm ...
    */
   (void) alarm(0) ;

   current_time = time((time_t *) NULL) ;
   retval = malrmlr_cancel_alarm(alarmid, current_time, remaining_secs) ;

   /*
    * Schedule the next system alarm ...
    */
   (void) alarm(malrmlr_next_alarm_secs(current_time)) ;

   return(retval) ;

/*END of MALRM_cancel()*/
}


/**************************************************************************
 Description: Deregister an MALRM callback routine for a given alarm
       Input: alarm id, pointer to MALRM callback routine
      Output:
     Returns: the number of remaining registered alarms, or one of the
              following negative numbers:

                MALRM_BAD_ALARMID
		MALRM_ALARM_NOT_REGISTERED (malrmlr_dereg_alarm())
		MALRM_SIGACTION_FAILED
		MALRM_SIGEMPTYSET_FAILED

       Notes:
 **************************************************************************/
int MALRM_deregister(malrm_id_t alarmid)
{
   time_t current_time ;
   int retval ;

   if (alarmid == 0) {
      return(MALRM_BAD_ALARMID) ;
   }

   /*
    * Cancel the previous system alarm ...
    */
   (void) alarm(0) ;

   current_time = time((time_t *) NULL) ;
   retval = malrmlr_dereg_alarm(alarmid, current_time) ;
   if (retval == 0) {

      /*
       * It is necessary to deregister the MALRM library signal handler ...
       */
      struct sigaction  sigact ;

      sigact.sa_handler = SIG_DFL ;

      retval = sigemptyset(&sigact.sa_mask) ;
      if (retval == -1) {
         return(MALRM_SIGEMPTYSET_FAILED) ;
      }

      sigact.sa_flags = (int) 0 ;

      retval = sigaction((int)  MALRM_ALARM_SIG,
     		(const struct sigaction *) &sigact , 
   		(struct sigaction *) NULL ) ;
      if (retval != 0) {
         return(MALRM_SIGACTION_FAILED) ;
      }

   } /*endif this was the last alarm callback routine registration */

   /*
    * Schedule the next system alarm ...
    */
   (void) alarm(malrmlr_next_alarm_secs(current_time)) ;


   return(retval) ;


/*END of MALRM_deregister()*/
}


/**************************************************************************
 Description: Register an alarm
       Input: alarm id, pointer to MALRM callback routine
      Output:
     Returns: the number of registered alarms, or one of the following
              negative error codes:

                MALRM_BAD_ALARMID
                MALRM_DUPL_REG			(malrmlr_reg_alarm())
		MALRM_SIGACTION_FAILED
		MALRM_SIGEMPTYSET_FAILED
                MALRM_SUSPECT_PTR
                MALRM_TOO_MANY_ALARMS		(malrmlr_reg_alarm())

       Notes:
 **************************************************************************/
int MALRM_register(malrm_id_t alarmid,void (*callback)())
{
   time_t current_time ;
   int retval ;
   int retval2 ;


   if (alarmid == 0) {
      return(MALRM_BAD_ALARMID) ;
   }

   if (callback == NULL) {
      return(MALRM_SUSPECT_PTR) ;
   }

   /*
    * Cancel the previous system alarm ...
    */
   (void) alarm(0) ;

   current_time = time((time_t *) NULL) ;

   retval = malrmlr_reg_alarm(alarmid,callback) ;
   if (retval == 1) {

      /*
       * It is necessary to register the MALRM library signal handler ...
       */
      struct sigaction  sigact ;

      sigact.sa_handler = (void (*)()) alarm_handler ;

      retval2 = sigemptyset(&sigact.sa_mask) ;
      if (retval2 == -1) {
         return(MALRM_SIGEMPTYSET_FAILED) ;
      }

      sigact.sa_flags = (int) 0 ;

      retval2 = sigaction((int)  MALRM_ALARM_SIG,
     		(const struct sigaction *) &sigact , 
   		(struct sigaction *) NULL ) ;
      if (retval2 != 0) {
         return(MALRM_SIGACTION_FAILED) ;
      }

   } /*endif this is the first alarm callback routine registration */


   /*
    * Schedule the next system alarm ...
    */
   (void) alarm(malrmlr_next_alarm_secs(current_time)) ;

   return(retval) ;

/*END of MALRM_register()*/
}


/**************************************************************************
 Description: Set a given (registered) MALRM alarm
       Input: alarm id
              alarm flags
              alarm start time
              alarm interval time (zeroes mean one-shot)
      Output:
     Returns: zero upon success, or one of the following negative error codes:

                MALRM_ALARM_NOT_REGISTERD (malrmlr_set_alarm())
                MALRM_BAD_ALARMID
                MALRM_BAD_START_TIME

       Notes:
 **************************************************************************/
int MALRM_set(malrm_id_t alarmid,
              time_t start_time,
              unsigned int interval_secs)
{

   int retval ;
   time_t current_time ;
   double t_diff ;

   if (alarmid == 0) {
         return(MALRM_BAD_ALARMID) ;
   }

   current_time = time((time_t *) NULL) ;

   /*
    * Ensure that the start time is reasonable ...
    */
   if (start_time == MALRM_START_TIME_NOW) {
      start_time = current_time ;
   }
   else {
      t_diff = difftime(start_time, current_time) ;
      if (t_diff < 0) {
         return(MALRM_BAD_START_TIME) ;
      }
   }

   /*
    * Cancel the previous system alarm ...
    */
   (void) alarm(0) ;

   retval = malrmlr_set_alarm(alarmid, start_time, interval_secs) ;

   /*
    * Schedule the next system alarm ...
    */
   (void) alarm(malrmlr_next_alarm_secs(current_time)) ;

   return(retval) ;

/*END of MALRM_set()*/
}



/**************************************************************************
 Description: Handle signal MALRM_ALARM_SIG delivered to this signal handler
              by the system.
       Input: void
      Output: alarm data to registered MALRM callback routine
     Returns: void
       Notes: ALL ROUTINES CALLED BY THIS SIGNAL HANDLER MUST THEMSELVES
              BE WRITTEN IN ACCORDANCE WITH GOOD SIGNAL-HANDLER DESIGN
              PRINCIPLES (e.g., use only reentrant functions!)

              errno is saved and restored, since this may be important
              to an interrupted system call.

 **************************************************************************/
static void alarm_handler()
{
   time_t current_time ;
   int errnosave ;

   errnosave = errno ;         /* for sake of any interrupted system call */

   current_time = time((time_t *) NULL) ;

   /*
    * Invoke the registered alarm callback routines as appropriate ... 
    */
   malrmlr_callbacks(current_time) ;

   /*
    * Schedule the next system alarm ...
    */
   (void) alarm(malrmlr_next_alarm_secs(current_time)) ;

   errno = errnosave ;

   return ;

/*END of alarm_handler()*/
}


#ifdef UTMAIN

#include <stdlib.h>

#define UT_PASSED	0
#define UT_FAILED	-1
#define UT_WHOAMI "malrm_lib_ut"

/*
 * Function Prototypes
 */
static void Callback0(malrm_id_t alarmid) ;
static void Callback1(malrm_id_t alarmid) ;


/*
 *      Unit Test Cases
 *      UT Case 1.1
 */
static int Ut_case_1_1(void) ;
static int Ut_case_1_2(void) ;
static int Ut_case_1_3(void) ;
static int Ut_case_1_4(void) ;


/**************************************************************************
 Description: This is the built-in Unit Test driver
       Input: void
      Output:
     Returns: EXIT_SUCCESS if all unit tests pass; otherwise EXIT_FAILURE
       Notes: Refer to SDF.
              EXIT_SUCCESS and EXIT_FAILURE exit codes are provided so that
              a shell script can recognize if one or more of the unit tests
              failed without having to examine the displayed data.
 **************************************************************************/
int main(int argc, char **argv)
{
   int exitcode = EXIT_SUCCESS ;
   int retval ;

   /*
    * Execute automated (canned) unit tests ...
    */
   retval = Ut_case_1_1() ;
   if (retval != UT_PASSED) {
      exitcode = EXIT_FAILURE ;
   }

   retval = Ut_case_1_2() ;
   if (retval != UT_PASSED) {
      exitcode = EXIT_FAILURE ;
   }

   retval = Ut_case_1_3() ;
   if (retval != UT_PASSED) {
      exitcode = EXIT_FAILURE ;
   }

   retval = Ut_case_1_4() ;
   if (retval != UT_PASSED) {
      exitcode = EXIT_FAILURE ;
   }

   exit(exitcode) ;

/*END of main()*/
}


/**************************************************************************
		UUT: MALRM_register()

 Description: Unit Test Case 1.1 Register Exceptions
       Input: void
      Output: none
     Returns: void
       Notes: Refer to SDF
 **************************************************************************/
static int Ut_case_1_1()
{
   malrm_id_t alarmid ;
   time_t curtime ;
   int expected ;
   int fxn_return = UT_PASSED ;
   register int i ;
   int retval ;
   char subtest_id ;
   static char *utcase = "UT Case 1.1 Register Exceptions" ;
   static char *uut = "MALRM_register" ;


   curtime = time((time_t *) NULL) ;

   (void) printf("BEGIN %40s ... %s", utcase, ctime(&curtime)) ;

   /*
    * Subtest a: attempt to register an invalid alarm ID
    */
   subtest_id = 'a' ;
   alarmid = 0 ;
   expected = MALRM_BAD_ALARMID ;
   retval = MALRM_register(alarmid, Callback0) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }


   /*
    * Subtest b: attempt to re-register an alarm ...
    */
   subtest_id = 'b' ;
   alarmid = 1 ;
   expected = 1 ;
   retval = MALRM_register(alarmid, Callback0) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   expected = MALRM_DUPL_REG ;
   retval = MALRM_register(alarmid, Callback0) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   (void) MALRM_deregister(alarmid) ;

   /*
    * Subtest c: attempt to register NULL callback 
    */
   subtest_id = 'c' ;
   alarmid = 1 ;
   expected = MALRM_SUSPECT_PTR ;

   retval = MALRM_register(alarmid, NULL) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   /*
    * Subtest d: attempt to register too many alarms
    */
   subtest_id = 'd' ;
   for (i=0; i < MALRM_MAX_ALARMS; ++i) {
      alarmid = i+1 ;
      (void) MALRM_register(alarmid, Callback0) ;
   }

   alarmid = MALRM_MAX_ALARMS + 1 ;
   expected = MALRM_TOO_MANY_ALARMS ;
   retval = MALRM_register(alarmid, Callback0) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   (void) printf("  END %40s ... %s", utcase, ctime(&curtime)) ;

   /*
    * Cleanup ...
    */
   for (i=0; i < MALRM_MAX_ALARMS; ++i) {
      alarmid = i+1 ;
      (void) MALRM_deregister(alarmid) ;
   }

   return(fxn_return) ;

/*END of Ut_case_1_1()*/
}


/**************************************************************************
		UUT: MALRM_deregister()

 Description: Unit Test Case 1.2 Deregister Exceptions
       Input: void
      Output: none
     Returns: void
       Notes: Refer to SDF
 **************************************************************************/
static int Ut_case_1_2()
{
   malrm_id_t alarmid ;
   time_t curtime ;
   int expected ;
   int fxn_return = UT_PASSED ;
   int retval ;
   char subtest_id ;
   static char *utcase = "UT Case 1.2 Deregister Exceptions" ;
   static char *uut = "MALRM_deregister" ;


   curtime = time((time_t *) NULL) ;

   (void) printf("BEGIN %40s ... %s", utcase, ctime(&curtime)) ;

   /*
    * Subtest a: attempt to deregister an invalid alarm ID
    */
   subtest_id = 'a' ;
   alarmid = 0 ;
   expected = MALRM_BAD_ALARMID ;
   retval = MALRM_deregister(alarmid) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   /*
    * Subtest b: attempt to deregister an unregistered alarm ID
    */
   subtest_id = 'b' ;
   alarmid = 1 ;
   expected = MALRM_ALARM_NOT_REGISTERED ;
   retval = MALRM_deregister(alarmid) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   (void) printf("  END %40s ... %s", utcase, ctime(&curtime)) ;


   return(fxn_return) ;

/*END of Ut_case_1_2()*/
}


/**************************************************************************
		UUT: MALRM_set()

 Description: Unit Test Case 1.3 Set Exceptions
       Input: void
      Output: none
     Returns: void
       Notes: Refer to SDF
 **************************************************************************/
static int Ut_case_1_3()
{
   malrm_id_t alarmid ;
   time_t curtime ;
   int expected ;
   int fxn_return = UT_PASSED ;
   unsigned int interval_secs ;
   int retval ;
   time_t start_time ;
   char subtest_id ;
   static char *utcase = "UT Case 1.3 Set Exceptions" ;
   static char *uut = "MALRM_set" ;

   curtime = time((time_t *) NULL) ;

   (void) printf("BEGIN %40s ... %s", utcase, ctime(&curtime)) ;

   /*
    * Subtest a: attempt to set an unregistered alarm
    */
   subtest_id = 'a' ;
   alarmid = 1 ;
   start_time = curtime ;
   interval_secs = 0 ;
   expected = MALRM_ALARM_NOT_REGISTERED ;
   retval = MALRM_set(alarmid, start_time, interval_secs) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   /*
    * Subtest b: attempt to set an invalid alarm ID
    */
   subtest_id = 'b' ;
   alarmid = 0 ;
   start_time = curtime ;
   interval_secs = 0 ;
   expected = MALRM_BAD_ALARMID ;
   retval = MALRM_set(alarmid, start_time, interval_secs) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   /*
    * Subtest c: attempt to set using an invalid start time
    */
   subtest_id = 'c' ;
   alarmid = 1 ;
   start_time = curtime ;
   sleep(1) ;
   interval_secs = 0 ;
   (void) MALRM_register(alarmid, Callback0) ;
   expected = MALRM_BAD_START_TIME ;
   retval = MALRM_set(alarmid, start_time, interval_secs) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   /*
    * Cleanup ...
    */
   (void) MALRM_deregister(alarmid) ;


   (void) printf("  END %40s ... %s", utcase, ctime(&curtime)) ;


   return(fxn_return) ;

/*END of Ut_case_1_3()*/
}


/**************************************************************************
		UUT: MALRM_cancel()

 Description: Unit Test Case 1.4 Cancel Exceptions
       Input: void
      Output: none
     Returns: void
       Notes: Refer to SDF
 **************************************************************************/
static int Ut_case_1_4()
{
   malrm_id_t alarmid ;
   time_t curtime ;
   int expected ;
   int fxn_return = UT_PASSED ;
   register int i ;
   unsigned int remaining_secs ;
   int retval ;
   char subtest_id ;
   static char *utcase = "UT Case 1.4 Cancel Exceptions" ;
   static char *uut = "MALRM_cancel" ;

   curtime = time((time_t *) NULL) ;

   (void) printf("BEGIN %40s ... %s", utcase, ctime(&curtime)) ;

   /*
    * Subtest a: attempt to cancel an invalid alarm ID
    */
   subtest_id = 'a' ;
   alarmid = 0 ;
   expected = MALRM_BAD_ALARMID ;
   retval = MALRM_cancel(alarmid, (unsigned int *) NULL) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   /*
    * Subtest b: attempt to cancel an unregistered alarm
    */
   subtest_id = 'b' ;
   alarmid = 1 ;
   expected = MALRM_ALARM_NOT_REGISTERED ;
   retval = MALRM_cancel(alarmid, (unsigned int *) NULL) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   /*
    * Subtest c: attempt to cancel a registered but unset alarm
    */
   subtest_id = 'c' ;
   alarmid = 1 ;
   (void) MALRM_register(alarmid, Callback0) ;
   expected = MALRM_ALARM_NOT_SET ;
   retval = MALRM_cancel(alarmid, (unsigned int *) NULL) ;
   if (retval == expected) {
      (void) printf("\tSubtest %c: PASS\n", subtest_id) ;
   }
   else {
      fxn_return = UT_FAILED ;
      (void) printf("\tSubtest %c: FAIL\n", subtest_id) ;
      (void) printf("\t\tEXPECT %20s retval: %d\n",uut,expected) ;
      (void) printf("\t\tACTUAL %20s retval: %d\n", uut,retval) ;
   }

   /*
    * Cleanup ...
    */
   (void) MALRM_deregister(alarmid) ;


   (void) printf("  END %40s ... %s", utcase, ctime(&curtime)) ;


   return(fxn_return) ;

/*END of Ut_case_1_4()*/
}


/**************************************************************************
 Description: MALRM callback routine
       Input: alarm ID
      Output: none
     Returns: none
       Notes:
 **************************************************************************/
static void Callback0(malrm_id_t alarmid)
{
   time_t current_time ;

   current_time = time((time_t *) NULL) ;
   (void) fprintf(stdout,"%s: Callback0 alarmid: %d %s",
		UT_WHOAMI,(int) alarmid,
                ctime(&current_time)) ;
   return ;

/*END of Callback0()*/
}


/**************************************************************************
 Description: MALRM callback routine
       Input: alarm ID
      Output: none
     Returns: none
       Notes:
 **************************************************************************/
static void Callback1(malrm_id_t alarmid)
{
   time_t current_time ;

   current_time = time((time_t *) NULL) ;
   (void) fprintf(stdout,"%s: Callback1 alarmid: %d %s",
		UT_WHOAMI,(int) alarmid,
                ctime(&current_time)) ;
   return ;

/*END of Callback1()*/
}
#endif /*DO NOT REMOVE!*/
