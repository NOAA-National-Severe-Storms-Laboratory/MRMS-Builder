/****************************************************************
		
    GZIP implementation of the CMP API used by RMT.

*****************************************************************/

/*
 * RCS info 
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: cmp_gzip.c 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */

/* System include files */

#include <config.h>
#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
#include <unistd.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>

#include <misc.h>

#define CMP_MAGIC_NUMBER 0x74928356
#define MIN_COMPRESS_SIZE 256

static char *Sbuf = NULL;	/* shared buffer */
static int Sb_size = 0;		/* size of the shared buffer */

static int (*Zuncompress) (unsigned char *, unsigned long *, 
		const unsigned char *, unsigned long) = NULL;
static int (*Zcompress) (unsigned char *, unsigned long *, 
		const unsigned char *, unsigned long) = NULL;

extern int compress (char *buf, unsigned long *cs, 
			const char *data, unsigned long size);
extern int uncompress (char *buf, unsigned long *cs, 
			const char *data, unsigned long size);

static void Maintenance (int new_size);

/****************************************************************
			
    Compresses "data" of "size" bytes and returns the pointer to the
    compressed data. NULL is returned in case of failure. The size of
    the compressed data is returned with "csize". A magic number and
    the size of original data is put in front of the compressed data.
    The CMP module uses an shared internal buffer for returning data.
    The buffer can be freed with CMP_free_buffer. Because the buffer
    is shared, one cannot pass the data returned from a CMP function
    to another CMP function.

****************************************************************/

char *CMP_compress (int size, char *data, int *csize) {
    int cs, ret, s, *ip;

    if (size == 0) {
	*csize = 0;
	return (data);
    }

    s = (int)((float)size * 1.01f) + 13;
    if (s > Sb_size)
	Maintenance (s);

    if (size < MIN_COMPRESS_SIZE) {	/* no compress */
	memcpy (Sbuf + 2 * sizeof (int), data, size);
	*csize = size + 2 * sizeof (int);
	ip = (int *)Sbuf;
	ip[0] = htonl (CMP_MAGIC_NUMBER + 1);
	ip[1] = htonl (size);
	return (Sbuf);
    }

    if (Zcompress == NULL)
	return (NULL);
    cs = Sb_size;
    ret = Zcompress (Sbuf + 2 * sizeof (int), (unsigned long *)&cs, 
					data, (unsigned long)size);
    if (ret != 0)
	return (NULL);
    *csize = cs + 2 * sizeof (int);
    ip = (int *)Sbuf;
    ip[0] = htonl (CMP_MAGIC_NUMBER);
    ip[1] = htonl (size);
    return (Sbuf);
}

/****************************************************************
			
    Decompresses "data" of "size" bytes and returns the pointer to the
    decompressed data. The size of the decompressed data is returned
    with "dsize". The CMP module uses an shared internal buffer for 
    returning data. The buffer can be freed with CMP_free_buffer.
    NULL is returned in case of failure.

****************************************************************/

char *CMP_decompress (int size, char *data, int *dsize) {
    int cs, ret, s, *ip;

    if (size == 0) {
	*dsize = 0;
	return (data);
    }

    ip = (int *)data;
    if (ntohl (ip[0]) == CMP_MAGIC_NUMBER + 1) {	/* no compress */
	s = ntohl (ip[1]);
	if (size < s + 2 * sizeof (int))
	    return (NULL);
	if (s > Sb_size)
	    Maintenance (s);
	memcpy (Sbuf, data + 2 * sizeof (int), s);
	*dsize = s;
	return (Sbuf);
    }

    if (ntohl (ip[0]) != CMP_MAGIC_NUMBER)
	return (NULL);
    s = ntohl (ip[1]);
    if (s <= 0)
	return (NULL);
    if (s > Sb_size)
	Maintenance (s);
    if (Zuncompress == NULL)
	return (NULL);
    cs = Sb_size;
    ret = Zuncompress (Sbuf, (unsigned long *)&cs, 
			data + 2 * sizeof (int), 
			(unsigned long)(size - 2 * (int)sizeof (int)));
    if (ret != 0)
	return (NULL);
    *dsize = cs;
    return (Sbuf);
}

/****************************************************************
			
    Frees the shared buffer.

****************************************************************/

void CMP_free_buffer (void *buf) {

    if (Sbuf != NULL)
	free (Sbuf);
    Sbuf = NULL;
    Sb_size = 0;
}

/****************************************************************
			
    The maintenance function: Extends the size of the shared buffer 
    to "new_size" and load the compression functions.

****************************************************************/

static void Maintenance (int new_size) {

    if (Zcompress == NULL) {
	void *handle, *error;
	if ((handle = dlopen ("libz.so", RTLD_LAZY)) == NULL) {
	    MISC_log ("%s\n", dlerror ());
	    return;
	}
	Zuncompress = (int (*)())dlsym (handle, "uncompress");
	if (Zuncompress != NULL)
	    Zcompress = (int (*)())dlsym (handle, "compress");
	if ((error = dlerror()) != NULL) {
	    MISC_log ("%s\n", error);
	    return;
	}
    }
    if (Sbuf != NULL)
	free (Sbuf);
    Sbuf = MISC_malloc (new_size + 1024);
    Sb_size = new_size + 1024;
    return;
}


