/*************************************************************************

      Module: MISC_rsrc.c

 Description:

	Miscellaneous Services "wrapper" resource-management functions.

    Resource-management functions are typically (at present) non-POSIX,
    so we have decided to "wrap" these functions.

	Functions that are public are defined in alphabetical order at
	the top of this file and are identified with a prefix of
	"MISC_rsrc_".

	Functions that are private to this file are defined in alphabetical
	order, following the definition of the public functions.


 Assumptions:

**************************************************************************/

/*
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: misc_rsrc.c 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */

/*
 * System Include Files/Local Include Files
 */
#include <config.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>            /* strcat()                                */

#include <misc.h>
#include <cs.h>                /* CS_NAME                                 */

                               /* The placement of these sytem header file*/
                               /* #include's is important: otherwise      */
                               /* we have Solaris compiler problems       */
#ifdef _POSIX_C_SOURCE
#undef _POSIX_C_SOURCE
#include <sys/resource.h>      /* getrlimit(), setrlimit(), struct rlimit */
#define _POSIX_C_SOURCE
#else
#include <sys/resource.h>      /* getrlimit(), setrlimit(), struct rlimit */
#endif

/*
 * Constant Definitions/Macro Definitions/Type Definitions
 */
#ifdef LINUX
/* typedef long int rlim_t ; */
#endif
#define TMP_BUF_SIZE 1024

/*
 * External Globals
 */

/*
 * Static Globals
 */

/*
 * Static Function Prototypes
 */
static int Rm_trailing_slash_and_ret_strlen (char *str);



/**************************************************************************
 Description: Get/Set "number of open files" resource (per-process).
       Input: requested resource limit
      Output: process resource limit may be changed
     Returns: (positive) resource limit upon success; otherwise one of the
              following negative values:

              MISC_RSRC_GET_ERR
              MISC_RSRC_SET_ERR

       Notes: The RLIMIT_NOFILE resource limit will be incremented iff.
              the requested resource limit exceeds the current resource
              limit.  Otherwise, we simply return the current resource
              limit.
 **************************************************************************/
int
MISC_rsrc_nofile(int nofile)
{
    struct rlimit rsrc_limit ; /* resource limits structure               */

    /*
     * Get the current resource limit ...
     */
    if (getrlimit(RLIMIT_NOFILE, &rsrc_limit) != 0) {
        return(MISC_RSRC_GET_ERR) ;
    }

    if (nofile > (unsigned int) rsrc_limit.rlim_cur) {
        /*
         * Set the resource limit value ...
         */
        rsrc_limit.rlim_cur = nofile ;
        if (setrlimit(RLIMIT_NOFILE, (const struct rlimit *) &rsrc_limit)
                != 0) {
            return(MISC_RSRC_SET_ERR) ;
        }
    }

    return((int) rsrc_limit.rlim_cur) ;

/*END of MISC_rsrc_nofile()*/
}

/**
 Description: Returns the working directory path.
       Input: buf_size - size of the buffer for returning the path.
      Output: buf - the buffer for returning the path.
     Returns: (positive) path string length upon success; otherwise a 
		negative MISC_RSRC error number.
 */
int MISC_get_work_dir (char *buf, int buf_size)
{
    char tb[TMP_BUF_SIZE], *env;
    DIR *dir;
    int len;

    if ((env = getenv ("WORK_DIR")) != NULL) {
	len = strlen (env);
	if (len == 0)
	    return (MISC_RSRC_ENVS_UNDEFINED);
	if (len + 1 > TMP_BUF_SIZE)
	    return (MISC_RSRC_VAR_TOO_LARGE);
	strcpy (tb, env);
	len = Rm_trailing_slash_and_ret_strlen (tb);
    }

    else if ((env = getenv ("HOME")) != NULL) {
	if (strlen (env) + 5 > TMP_BUF_SIZE)
	    return (MISC_RSRC_VAR_TOO_LARGE);
	strcpy (tb, env);
	len = Rm_trailing_slash_and_ret_strlen (tb);
	(void) strcat (tb, "/tmp");
	len += 4;
    }

    else
	return (MISC_RSRC_ENVS_UNDEFINED);

    if (len + 1 > buf_size)
	return (MISC_RSRC_BUF_TOO_SMALL);
    else
	strcpy (buf, tb);

    dir = opendir (tb);
    if (dir != NULL)
	closedir (dir);
    else
	return (MISC_RSRC_DIR_MISSING);

    return (len);

/*END of MISC_get_work_dir()*/
}



/**
 Description: Returns the configuration directory path.
       Input: buf_size - size of the buffer for returning the path.
      Output: buf - the buffer for returning the path.
     Returns: (positive) path string length upon success; otherwise a 
		negative MISC_RSRC error number.
 */
int
MISC_get_cfg_dir (char *buf, int buf_size)
{
    char tb[TMP_BUF_SIZE], *env;
    int len;

    if ((env = getenv ("CFG_DIR")) != NULL) {
	len = strlen (env);
	if (len == 0)
	    return (MISC_RSRC_ENVS_UNDEFINED);
	if (len + 1 > TMP_BUF_SIZE)
	    return (MISC_RSRC_VAR_TOO_LARGE);
	strcpy (tb, env);
	len = Rm_trailing_slash_and_ret_strlen (tb);
    }
    else
	return (MISC_RSRC_ENVS_UNDEFINED);

    if (len + 1 > buf_size)
	return (MISC_RSRC_BUF_TOO_SMALL);
    else {
	strcpy (buf, tb);
	return (len);
    }

/*END of MISC_get_cfg_dir()*/
}



/**************************************************************************
 Description: Removes trailing "/" of a string, except the first char in
		the string and returns the string length.
       Input/Output: str - the string to be processed.
     Returns: the string length.
 **************************************************************************/

static int Rm_trailing_slash_and_ret_strlen (char *str)
{
    char *pt;
    int len;

    len = strlen (str);
    pt = str + len - 1;
    while (pt > str && *pt == '/') {
	*pt = '\0';
	pt--;
	len--;
    }
    return (len);

/*END of Rm_trailing_slash_and_ret_strlen()*/
}

/**************************************************************************

    Make directoty "path". This calls mkdir recursively to create the 
    dir. Returns 0 on success or -1 on failure.

 **************************************************************************/

int MISC_mkdir (char *path) {
    char buf[256], *p;

    if (mkdir (path, 0777) == 0 ||
	errno == EEXIST)
	return (0);
    if (errno != ENOENT ||
	strlen (path) >= 256)
	return (MISC_MKDIR_FAILED);
    strcpy (buf, path);
    p = buf + strlen (buf) - 1;
    while (p > buf && *p != '/')
	p--;
    if (p == buf)
	return (MISC_MKDIR_FAILED);
    *p = '\0';
    if (MISC_mkdir (buf) < 0)
	return (MISC_MKDIR_FAILED);
    return (MISC_mkdir (path));
}
