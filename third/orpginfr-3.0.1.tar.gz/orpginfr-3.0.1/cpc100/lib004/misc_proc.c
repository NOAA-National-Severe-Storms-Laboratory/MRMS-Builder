/*************************************************************************

    Module: misc_proc.c

    Miscellaneous process-related functions.

**************************************************************************/

/*
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: misc_proc.c 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */

#include <config.h>
#include <stdio.h>
#include <stdlib.h>            /* system()                                */
#include <unistd.h>            /* getpid(), unlink()                      */

#include <sys/types.h>         /* closedir(), open(), opendir(),readdir() */
                               /* stat(), fcntl()                         */
#include <dirent.h>            /* closedir(), opendir(), readdir()        */
#include <sys/stat.h>          /* open(), stat()                          */
#include <fcntl.h>             /* fcntl(), open()                         */
#include <unistd.h>            /* read(), fcntl()                         */
#include <string.h>            /* strspn()                                */
#include <errno.h>            /*                                 */
#include <signal.h>
#include <dlfcn.h>

#if (defined (LINUX)) || (defined (__WIN32__))
#include <sys/procfs.h>
#include <sys/resource.h>
#include <sys/wait.h>
#endif
#if (defined (IRIX))
#include <sys/procfs.h>
#include <sys/wait.h>
#endif
#if (defined (SUNOS))
#include <procfs.h>
#endif

#include <misc.h>
#include <str.h>

#define MAX_N_ARGS 32
#define MAX_CMD_LENGTH 256
#define MAX_SH_LENGTH 64

#define PSINFO_PATHLEN 24     /* we need only enough space for           */
                               /* "/proc/######/psinfo"                   */
#define SYSTEM_CMDLEN   128
#define SYSTEM_CMDSIZ   ((SYSTEM_CMDLEN) + 1)
#define NAME_LEN 128

#define MISC_CP_BUFSIZE	 512

typedef struct {		/* coprocess struct */
    char *cmd;			/* coprocess command */
    int flag;			/* open flag - not used for the moment */
    int up;			/* The coprocess is up and running */
    int in_fd;			/* coprocess stdin fd */
    int out_fd;			/* coprocess stdout fd */
    int err_fd;			/* coprocess stderr fd */
    char out_buf[MISC_CP_BUFSIZE];
    char err_buf[MISC_CP_BUFSIZE];
				/* buffers for reading stdout and stderr */
    int out_nbytes;		/* number of bytes in out_buf */
    int err_nbytes;		/* number of bytes in err_buf */
    pid_t pid;			/* coprocess pid */
} Cp_struct_t;

static int Sig_pipe_received;	/* SIGPIPE received - used by MISC_cp */

static int Setsid = 1;

static int Execute_cmd (const char *cmd);
static void Redirect_output (int *fd);
static int Read_output (int fd, int ofd, char *obuf, int bsize);
static int Execute (char *cmd, char *ofile,
		char *obuf, int bsize, int *ret_cnt, int fg, int pp1);
static int Fork_execute (char *cmd, char *ofile,
			char *obuf, int bsize, int *n_bytes, int fg);
static void Close_files (int *opp, int fd, int pp1, int nfds);
static char *Get_token (char *str, char **next, int *len);
static int Read_pipe (int fd, char *buf, int buf_size);
static int Parse_cmd (char *cmd, char *buf, int buf_size, 
					char **av, int maxn_args);
static int Read_cp_output (int fd, char *rbuf, int *n_bytes, 
					char *buf, int b_size);
static void Sig_pipe (int sig);
static int Close_fd_return (int *fd, char *cp, int ret);


/******************************************************************

    This function is removed.

******************************************************************/

void MISC_system_shell (char *shell_cmd) {
    return;
}

/******************************************************************

    Turns on/off setsid call.

******************************************************************/

void MISC_system_setsid (int yes) {
    Setsid = yes;
}

/******************************************************************

    MISC_system with output piped into "obuf" of size "bsize". Total
    number of output bytes is returned in "n_bytes".

******************************************************************/

int MISC_system_to_buffer (char *cmd, char *obuf, int bsize, int *n_bytes) {
    char *cmd1, *ofile;
    int fg;
    int bg_found, redirect_found, len;
    int redirect_count, bg_count;
    char cbuf[MAX_CMD_LENGTH];
    char *pt, *next;

    if (bsize > 0 && obuf != NULL)
	obuf[0] = '\0';
    if (n_bytes != NULL)
	*n_bytes = 0;

    if (strlen (cmd) >= MAX_CMD_LENGTH)
	return (MISC_SYSTEM_CMD_TOO_LONG);
    strcpy (cbuf, cmd);
    cmd1 = ofile = NULL;
    fg = 1;
    redirect_count = bg_count = 0;
    bg_found = redirect_found = 0;
    pt = Get_token (cbuf, &next, &len);
    while (1) {
	if (next == NULL)
	    return (MISC_SYSTEM_SYNTAX_ERROR);
	if (pt == NULL)
	    break;

	if (*pt == '|' && len == 1) {
	    return (MISC_SYSTEM_SYNTAX_ERROR);
	}
	else if (*pt == '&' && len == 1) {
	    *pt = '\0';
	    bg_found = 1;
	    bg_count++;
	    fg = 0;
	}
	else if (*pt == '>' && len == 1) {
	    *pt = '\0';
	    redirect_found = 1;
	    redirect_count++;
	}
	else if (redirect_found) {
	    if (cmd1 == NULL || ofile != NULL)
		return (MISC_SYSTEM_SYNTAX_ERROR);
	    ofile = pt;
	    if (ofile[len] != ' ' && ofile[len] != '\0')
		return (MISC_SYSTEM_SYNTAX_ERROR);
	    ofile[len] = '\0';
	    redirect_found = 0;
	}
	else if (bg_found)
	    return (MISC_SYSTEM_SYNTAX_ERROR);
	else if (cmd1 == NULL)
	    cmd1 = pt;
	pt = Get_token (next, &next, &len);
    }
    if (cmd1 == NULL || bg_count > 1 || redirect_count > 1)
	return (MISC_SYSTEM_SYNTAX_ERROR);

    return (Fork_execute (cmd1, ofile, obuf, bsize, n_bytes, fg));
}

/******************************************************************

    Returns the pointer to the first token in "str" or NULL on
    failure. A token is a string of chars separated by spaces. A
    string of arbitrary chars quated by " is also a token. " is not
    considered as part of the token. There is no escape mechanism
    for ". Quated token must also be separated by space. The token
    length and the pointer that pointing to the char after the
    token are returned with "len" and "next". On syntex error,
    next is set to NULL. Get_token dosn't modify "str".

******************************************************************/

static char *Get_token (char *str, char **next, int *len) {
    char *pt, c, *st;
    int inquat;

    pt = str;
    st = NULL;
    inquat = 0;
    *next = NULL;
    while ((c = *pt) != '\0') {
	if (c == '"') {
	    if (inquat) {
		if (pt == st || (pt[1] != ' ' && pt[1] != '\0'))
		    return (NULL);
		*next = pt + 1;
		*len = pt - st;
		return (st);
	    }
	    else if (pt > str && pt[-1] != ' ')
		return (NULL);
	    inquat = 1;
	    if (st == NULL)
		st = pt + 1;
	    pt++;
	    continue;
	}
	if (inquat) {
	    pt++;
	    continue;
	}
	if (c == ' ') {
	    if (st != NULL) {
		*len = pt - st;
		*next = pt + 1;
		return (st);
	    }
	}
	else if (st == NULL)
	    st = pt;
	pt++;
    }
    if (inquat)
	return (NULL);
    *next = pt;
    *len = pt - st;
    return (st);
}

/******************************************************************

    In order to start a background command running independently of 
    this process, we have to fork child, which executes the command
    and then terminates (This works regardless of the calling
    process's SIGCHLD action). In order to pass the return value 
    (pid on success or error code on failure) we build a pipe. We 
    must also set the SIGCHLD to SIG_DFL so waitpid will work as 
    expected regardless the calling process's SIGCHLD action. We
    block signals while we call fork. This is necessary for SUNOS's
    pthreaded applications which can block in fork while receiving 
    a signal and an i/o being performed in the signal handler. This
    does not happen in single threaded applications as tested. I 
    don't know what will happen on other OS. Do I need to do this 
    for other fork calls (running in foreground) in this module? I 
    havn't tested yet.

******************************************************************/

static int Fork_execute (char *cmd, char *ofile,
			char *obuf, int bsize, int *n_bytes, int fg) {
    struct sigaction child, act;
    int pp[2];		/* for status reporting from children */
    int nread, stat, ret;

    act.sa_handler = SIG_DFL;
    act.sa_flags = 0;
    sigemptyset (&act.sa_mask);
    if (sigaction (SIGCHLD, &act, &child) < 0)
	return (MISC_SYSTEM_SIGACTION);

    pp[0] = pp[1] = -1;
    if (pipe (pp) == -1) {
	ret = MISC_SYSTEM_PIPE;
	goto cleanup;
    }
    fcntl (pp[0], F_SETFD, FD_CLOEXEC | fcntl (pp[0], F_GETFD));
    fcntl (pp[1], F_SETFD, FD_CLOEXEC | fcntl (pp[1], F_GETFD));

    ret = 0;
    if (!fg) {
	int pid, child_status;
	sigset_t new, old;

	sigfillset (&new);
	if (sigprocmask (SIG_BLOCK, &new, &old) < 0) {
	    ret = MISC_SYSTEM_SIGPROCMASK;
	    goto cleanup;
	}
	pid = fork();
	if (pid == -1) {
	    ret = MISC_SYSTEM_FORK;
	    goto cleanup;
	}
	sigprocmask (SIG_SETMASK, &old, NULL);
	if (pid == 0) {		/* in child */
	    int ppb[2];		/* for status reporting from children */
	    int status;

	    if (Setsid)
		setsid ();
	    close (pp[0]);
	    if (pipe (ppb) == -1)
		status = MISC_SYSTEM_PIPE;
	    else {
		fcntl (ppb[0], F_SETFD, FD_CLOEXEC | fcntl (ppb[0], F_GETFD));
		fcntl (ppb[1], F_SETFD, FD_CLOEXEC | fcntl (ppb[1], F_GETFD));
		status = Execute (cmd, ofile, obuf, 
					    bsize, n_bytes, fg, ppb[1]);
		close (ppb[1]);
		if (Read_pipe (ppb[0], (char *)&stat, 
					    sizeof (int)) == sizeof (int))
		    status = stat;
	    }
	    while ((ret = write (pp[1], &status, sizeof (int))) < 0 && 
							errno == EINTR);
	    exit (0);
	}
	close (pp[1]);
	pp[1] = -1;
	nread = Read_pipe (pp[0], (char *)&stat, sizeof (int));
	while ((ret = waitpid (pid, &child_status, 0)) == -1 && 
							errno == EINTR);
	if (ret < 0) {
	    ret = MISC_SYSTEM_BG_DIED;
	    goto cleanup;
	}
	if (child_status != 0) {
	    ret = MISC_SYSTEM_BG_FAILED; 
	    goto cleanup;
	}
    }
    else {
	ret = Execute (cmd, ofile, obuf, bsize, n_bytes, fg, pp[1]);
	close (pp[1]);
	pp[1] = -1;
	nread = Read_pipe (pp[0], (char *)&stat, sizeof (int));
    }

    if (nread >= sizeof (int))
	ret = stat;

cleanup:
    if (pp[0] >= 0)
	close (pp[0]);
    if (pp[1] >= 0)
	close (pp[1]);
    sigaction (SIGCHLD, &child, NULL);	/* recorver */
    return (ret);
}

/*********************************************************************

    Read at most "buf_size" bytes from pipe "fd" and put them in "buf".
    Returns the number of bytes read.

*********************************************************************/

static int Read_pipe (int fd, char *buf, int buf_size) {
    int nread, n;

    nread = 0;
    while (1) {
	n = read (fd, buf + nread, buf_size - nread);
	if (n == 0 || (n < 0 && errno != EINTR))
	    return (nread);
	if (n > 0)
	    nread += n;
	if (nread >= buf_size)
	    return (nread);
    }
}

/******************************************************************

    Executes commands "cmd". If "fg" is zero (background mode), this 
    function returns with cmd running in background. The outputs of 
    cmd is piped to the file named "ofile" if ofile != NULL. The file 
    contents are deleted if file "ofile" exists.

    In the foreground mode, "fg" != 0, The function will not return 
    until "cmd" terminates. If "ofile" != NULL, the output is
    piped into file "ofile". Otherwise, if bsize > 0, the outputs 
    are piped into buffer "obuf" of size "bsize". Extra data are 
    discarded. If bsize == 0, all output data are discarded. If 
    bsize < 0, all output data goes to the stdout.

    Note that here we use pipes to implement the behavior that if 
    this application is killed, then cmd will die. This function does 
    not change the signal status and frees all resources used in it. 
    We don't currently do SIGINT and SIGQUIT as done in system.c.

    On success, returns the pid of cmd if "fg" == 0 or the 
    status as returned by "system" if "fg" != 0. The total number
    of output bytes is returned in "n_bytes" if "n_bytes" is not 
    NULL. The function returns a negative error code on failure.

******************************************************************/

static int Execute (char *cmd, char *ofile,
		char *obuf, int bsize, int *n_bytes, int fg, int pp1) {
    int pid, fd, opp[2];
    int status, err, t;
    static int max_n_files = 0;
 
    if (max_n_files == 0) {
	struct rlimit rsrc_limit;	/* resource limits structure */
	if (getrlimit (RLIMIT_NOFILE, &rsrc_limit) != 0)
            return (MISC_SYSTEM_GETRLIMIT);
	max_n_files = rsrc_limit.rlim_cur;
    }

    if (cmd == NULL)
	return (MISC_SYSTEM_SYNTAX_ERROR);

    status = 0;
    opp[0] = opp[1] = -1;
    fd = -1;
    if (ofile != NULL) {
	bsize = 0;
	fd = MISC_open (ofile, O_WRONLY | O_CREAT | O_TRUNC, 0664);
	if (fd < 0) {
	    status = MISC_SYSTEM_OPEN;
	    goto cleanup;
	}
    }
    if (fg) {
	if (pipe (opp) == -1) {
	    status = MISC_SYSTEM_PIPE;
	    goto cleanup;
	}
    }

    pid = fork();
    if (pid == -1) {
	status = MISC_SYSTEM_FORK;
	goto cleanup;
    }
    if (pid == 0) {		/* in child */
	Close_files (opp, fd, pp1, max_n_files);
	if (fd >= 0)	/* send to fd */
	    Redirect_output (&fd);
	else if (fg)		/* pipe to parent */
	    Redirect_output (opp + 1);

	if (fd >= 0)
	    close (fd);
	if (opp[0] >= 0)
	    close (opp[0]);
	if (opp[1] >= 0)
	    close (opp[1]);

	status = Execute_cmd (cmd);
	if (status < 0) {
	    while (write (pp1, &status, sizeof (int)) < 0 && 
							errno == EINTR);
	}
	exit (status);
    }

    /* in parent */
    if (fg) {
	int cnt, st;
	if (opp[1] >= 0) {
	    close (opp[1]);
	    opp[1] = -1;
	}
	if (bsize == -2) {
	    status = opp[0];	/* return this pipe fd */
	    opp[0] = -1;	/* prevent from being closed */
	    goto cleanup;
	}
	cnt = Read_output (opp[0], fd, obuf, bsize);
	if (cnt < 0)
	    status = cnt;
	else {
	    if (n_bytes != NULL)
		*n_bytes = cnt;
	    if (cnt >= bsize)
		cnt = bsize - 1;
	    if (bsize > 0 && obuf != NULL)
		obuf[cnt] = '\0';
	}
	close (opp[0]);
	opp[0] = -1;
	while ((t = waitpid (pid, &st, 0)) == -1 && errno == EINTR);
	if (t == -1)
	    status = MISC_SYSTEM_WAITPID;
	if (status >= 0)
	    status = st;
    }
    else
	status = pid;

cleanup:
    err = errno;
    if (fd >= 0)
	close (fd);
    if (opp[0] >= 0)
	close (opp[0]);
    if (opp[1] >= 0)
	close (opp[1]);
    errno = err;

    return (status);
}

/*********************************************************************

    Redirects stdout and stderr to "fd".

*********************************************************************/

static void Redirect_output (int *fd) {
    dup2 (*fd, 1);
    dup2 (*fd, 2);
    close (*fd);
    *fd = -1;
}

/*********************************************************************

    Close all fds other than standard ports and those listed.

*********************************************************************/

static void Close_files (int *opp, int fd, int pp1, int nfds) {
    int i;

    for (i = 3; i < nfds; i++) {
	if (i == opp[0] || i == opp[1] || 
	    i == fd || i == pp1)
	    continue;
	if (fcntl (i, F_GETFD) != -1) 
	    MISC_close (i);
    }
}

/*********************************************************************

    Reads the the output from pipe "fd" until the pipe is broken. The
    data read are put in file "ofd" if it is >= 0. Otherwise if bsize 
    >= 0, they are put in "obuf" of size "bsize". Extra data are  
    discarded. If bsize < 0, data are sent to stdout. Returns the 
    total number of bytes read on success or a negative error code.

*********************************************************************/

#define BUF_SIZE 256

static int Read_output (int fd, int ofd, char *obuf, int bsize) {
    int cnt, nread;

    cnt = nread = 0;
    while (1) {
	char buf[BUF_SIZE + 1], *pt;
	int len, ret;

	if (cnt < bsize) {
	    pt = obuf + cnt;
	    len = bsize - cnt;
	}
	else {
	    pt = buf;
	    len = BUF_SIZE;
	}
	ret = read (fd, pt, len);
	if (ret > 0) {
	    nread += ret;
	    if (ofd >= 0) {
		if (write (ofd, pt, ret) != ret) {
		    return (MISC_SYSTEM_WRITE);
		}
	    }
	    else if (bsize < 0) {
		pt[ret] = '\0';
		printf ("%s", pt);
	    }
	    else if (cnt < bsize)
		cnt += ret;
	}
	else {
	    if (ret < 0) {
		if (errno == EINTR)
		    continue;
		return (MISC_SYSTEM_READ_PIPE);
	    }
	    break;
	}
    }
    return (nread);
}

/*********************************************************************

    Executes command "cmd" and returns -1 in case of failure. errno
    contains failure code. On success, it does not return.

*********************************************************************/

static int Execute_cmd (const char *cmd) {
    char *av[MAX_N_ARGS];
    char buf[MAX_CMD_LENGTH];
    int ret;

    Parse_cmd ((char *)cmd, buf, MAX_CMD_LENGTH, av, MAX_N_ARGS);
    ret = execvp (av[0], av);
    if (ret < 0)
	return (MISC_SYSTEM_EXECVP);
    return (0);
}

/******************************************************************

    Terminates the coprocess "cp" and frees up all resources.

******************************************************************/

void MISC_cp_close (void *cp) {
    Cp_struct_t *cps;

    cps = (Cp_struct_t *)cp;
    if (cps->up)
	kill (cps->pid, SIGTERM);
    close (cps->in_fd);
    close (cps->out_fd);
    close (cps->err_fd);
    MISC_free (cp);
}

/******************************************************************

    Reads a line from the output, stderr or stdout, of the coprocessor
    and puts it in "buf" of size "b_size". If b_size if too small,
    the line is truncated. The returned line is always a null-terminated 
    string. The read is non_blocking. If no line is ready, it returns 0.
    If reads stderr first. It returns MISC_CP_STDERR or MISC_CP_STDOUT
    to indicated where the line is read. If an error is detected, it
    terminates the coprocess and returns error code MISC_CP_DOWN.

******************************************************************/

int MISC_cp_read_from_cp (void *cp, char *buf, int b_size) {
    Cp_struct_t *cps;
    int ret;

    cps = (Cp_struct_t *)cp;
    if (!cps->up)
	return (MISC_CP_DOWN);

    ret = Read_cp_output (cps->err_fd, cps->err_buf, 
					&(cps->err_nbytes), buf, b_size);
    if (ret > 0)
	return (MISC_CP_STDERR);
    else if (ret == 0) {
	ret = Read_cp_output (cps->out_fd, cps->out_buf, 
					&(cps->out_nbytes), buf, b_size);
	if (ret > 0)
	    return (MISC_CP_STDOUT);
    }
    if (ret == 0)
	return (0);
    cps->up = 0;
    kill (cps->pid, SIGTERM);
    return (MISC_CP_DOWN);
}

/******************************************************************

    Reads data from pipe "fd" and puts it in "rbuf" of size 
    MISC_CP_BUFSIZE. There are already "nbytes" in the buffer. The 
    first line in "rbuf" is then moved to "buf" of size "b_size" if
    there is any. Return 1 if a line is put in "buf" or 0 if a line
    is not yet available. It returns -1 if the pipe is broken. 
    "nbytes" is update in this routine.

******************************************************************/

static int Read_cp_output (int fd, char *rbuf, int *n_bytes, 
					char *buf, int b_size) {
    int ret, nbytes;
    char *p, *p1;

    nbytes = *n_bytes;
    ret = read (fd, rbuf + nbytes, MISC_CP_BUFSIZE - nbytes - 2);
    if (ret == 0)
	return (-1);
    if (ret < 0 &&
	(errno != EWOULDBLOCK && errno != EINTR)) {
 	MISC_log ("MISC_cp: read failed (errno %d)\n", errno);
	return (-1);
    }
    if (ret > 0)
	nbytes += ret;
    *n_bytes = nbytes;

    if (nbytes == 0)
	return (0);

    if (nbytes >= MISC_CP_BUFSIZE - 2) {	/* we insert a line-return */
	rbuf[nbytes] = '\n';
	nbytes++;
    }
    rbuf[nbytes] = '\0';
    p = rbuf - 1;
    while ((p1 = strstr (p + 1, "\n")) != NULL)
	p = p1;
    if (p >= rbuf) {
	int len, n_copy;
	len = p - rbuf + 1;
	n_copy = len;
	if (n_copy >= b_size - 1)
	    n_copy = b_size - 1;
	memcpy (buf, rbuf, n_copy);
	buf[n_copy] = '\0';
	memmove (rbuf, rbuf + len, nbytes - len);
	nbytes -= len;
	*n_bytes = nbytes;
	return (1);
    }
    return (0);
}

/******************************************************************

    Writes null-terminated string "str" to the stdin of the coprocess
    "cp". It will block until success. If an error is detected, it
    terminates the coprocess and returns error code MISC_CP_DOWN. it
    returns 0 on success.

******************************************************************/

int MISC_cp_write_to_cp (void *cp, char *str) {
    Cp_struct_t *cps;
    int l, cnt, ret;

    cps = (Cp_struct_t *)cp;
    if (!cps->up)
	return (MISC_CP_DOWN);
    Sig_pipe_received = 0;
    l = strlen (str);
    cnt = 0;
    while (1) {
	ret = write (cps->in_fd, str, l);
	if (ret < 0) {
	    if (errno == EINTR || errno == EWOULDBLOCK) {
		sleep (1);
		continue;
	    }
 	    MISC_log ("MISC_cp: write failed (errno %d)\n", errno);
	    cps->up = 0;
	    break;
	}
	if (Sig_pipe_received || ret == 0) {
	    cps->up = 0;
	    break;
	}
	cnt += ret;
	if (cnt >= l)
	    break;
    }
    if (!cps->up) {
	kill (cps->pid, SIGTERM);
	return (MISC_CP_DOWN);
    }
    return (0);
}

/******************************************************************

    Starts a coprocess "cmd". Pipes are set to connect to the 
    coprocess for stdin, stdout and stderr. Reading of stdout and 
    stderr are set to non-blocking. On success, the pointer to
    the coprocess struct is returned which can be used as paramter
    for calling other MISC_cp functions. The function returns 0
    on success or a negative error code. This function changes the
    SIGCLD and SIGPIPE behaviors of the calling process. This can
    be improved later (using sigaction).

    The MISC_cp functions provide a convenient ways of running and 
    managing coprocesses. A failed coprocess can be detected when
    calling MISC_cp read/write functions. One can run multiple 
    coprocesses and can run them remotely with RPC. The limitation
    of using MISC_cp is the possible buffering of the standard ports.
    The coprocess must call fflush after writing each line to stdout
    or set buffer size to 0.

******************************************************************/

int MISC_cp_open (char *cmd, int flag, void **rcp) {
    int fd[6], i;
    pid_t pid;
    Cp_struct_t *cp;

    cp = (Cp_struct_t *)MISC_malloc (sizeof (Cp_struct_t) + strlen (cmd) + 1);
    cp->cmd = (char *)cp + sizeof (Cp_struct_t);
    strcpy (cp->cmd, cmd);
    cp->flag = flag;
    cp->up = 0;
    cp->in_fd = cp->out_fd = -1;
    cp->out_nbytes = cp->err_nbytes = 0;
    
    if (sigset (SIGCLD, SIG_IGN) == SIG_ERR ||	/* to avoid defunc */
	sigset (SIGPIPE, Sig_pipe) == SIG_ERR) {
 	MISC_log ("MISC_cp: sigset failed (errno %d)\n", errno);
	MISC_free (cp);
	return (MISC_CP_SIGSET_FALIED);
    }

    for (i = 0; i < 6; i++)
	fd[i] = -1;
    for (i = 0; i < 6; i += 2) {
	if (pipe (fd + i) < 0) {
 	    MISC_log ("MISC_cp: fork failed (errno %d)\n", errno);
	    return (Close_fd_return (fd, (char *)cp, MISC_CP_PIPE_FALIED));
	}
    }

    pid = fork ();
    if (pid < 0) {
 	MISC_log ("MISC_cp: fork failed (errno %d)\n", errno);
	return (Close_fd_return (fd, (char *)cp, MISC_CP_FORK_FALIED));
    }
    else if (pid > 0) {			/* parent */
	close (fd[0]);
	close (fd[3]);
	close (fd[5]);
	cp->in_fd = fd[1];
	cp->err_fd = fd[2];
	cp->out_fd = fd[4];
	if (fcntl (cp->out_fd, F_SETFL, 
			fcntl (cp->out_fd, F_GETFL) | O_NONBLOCK) < 0 ||
	    fcntl (cp->err_fd, F_SETFL, 
			fcntl (cp->err_fd, F_GETFL) | O_NONBLOCK) < 0) {
 	    MISC_log ("MISC_cp: fcntl (set non-blocking) failed (errno %d)\n", 
								errno);
	    return (Close_fd_return (fd, (char *)cp, MISC_CP_FCNTL_FALIED));
	}
	cp->up = 1;
	cp->pid = pid;
	*rcp = cp;
    }
    else {				/* child */
	char *av[MAX_N_ARGS], buf[MAX_CMD_LENGTH];
	close (fd[1]);
	close (fd[2]);
	close (fd[4]);
	if (fd[0] != STDIN_FILENO &&
	    dup2 (fd[0], STDIN_FILENO) != STDIN_FILENO)
	    exit (1);
	if (fd[3] != STDERR_FILENO &&
	    dup2 (fd[3], STDERR_FILENO) != STDERR_FILENO)
	    exit (1);
	if (fd[5] != STDOUT_FILENO &&
	    dup2 (fd[5], STDOUT_FILENO) != STDOUT_FILENO)
	    exit (1);
	if (Parse_cmd (cmd, buf, MAX_CMD_LENGTH, av, MAX_N_ARGS) <= 0) {
 	    MISC_log ("MISC_cp: Bad command (%s) failed\n");
	    exit (1);
	}
	if (execvp (av[0], av) < 0) {
 	    MISC_log ("MISC_cp: execvp (%s) failed (errno %d)\n", cmd, errno);
	    exit (1);
	}
    }
    return (0);
}

/******************************************************************

    Closes any open fd in the 6 pipe fds "fd" and returns "ret".
    It also fees pointer "cp".

******************************************************************/

static int Close_fd_return (int *fd, char *cp, int ret) {
    int i;

    MISC_free (cp);
    for (i = 0; i < 6; i++) {
	if (fd[i] >= 0)
	    close (fd[i]);
	fd[i] = -1;
    }
    return (ret);
}

/******************************************************************

    The SIGPIPE callback function.

******************************************************************/

static void Sig_pipe (int sig) {
    Sig_pipe_received = 1;
    return;
}

/******************************************************************

    Converts the string form command line "cmd" into vector form
    and returns it with "av". "buf" is the caller provided buffer 
    of size "buf_size" which must be large enough to hold "cmd".
    "maxn_args" is the buffer size of "av".

******************************************************************/

static int Parse_cmd (char *cmd, char *buf, int buf_size, 
					char **av, int maxn_args) {
    char *t, *next;
    int n, len;

    strncpy (buf, cmd, buf_size);
    buf[buf_size - 1] = '\0';
    n = 0;
    t = Get_token (buf, &next, &len);
    while (t != NULL) {
	t[len] = '\0';
	av[n] = t;
	n++;
	if (n >= maxn_args - 1)
	    break;
	t = Get_token (next, &next, &len);
    }
    av[n] = NULL;
    n++;
    return (n);
}


/*************************************************************************
 
    Retrieves stack info of process "pid" and returns it with "out_buf" of 
    size "out_buf_size". If "out_buf_size" <= 0, the stack info is printed
    to the stderr port. In cases of error conditions, an error message is 
    put in "out_buf". If the buffer size is not sufficient, the data
    is truncated and null terminated. We invoke command "pstack" to get
    the stack info. This works for both SunOs and Linux. "pstack" must 
    be installed and in the user's search path. Functions on the stack 
    below MISC_proc_printstack are discarded.

**************************************************************************/

#define TMP_BUF_SIZE 2048

void MISC_proc_printstack (int pid, int out_buf_size, char *out_buf) {
    char cmd[64] ;
    int retval, n_bytes;
    char tmp_buf[TMP_BUF_SIZE], *cpt;

    sprintf (cmd, "pstack %d", pid);
    retval = MISC_system_to_buffer (cmd, tmp_buf, TMP_BUF_SIZE, &n_bytes);

    if (retval < 0) {
	sprintf (tmp_buf, "MISC_system_to_buffer pstack pid %d failed (%d)\n",
								pid, retval);
	cpt = tmp_buf;
    }
    else {
	if (n_bytes >= TMP_BUF_SIZE)
	    n_bytes--;
	tmp_buf[n_bytes] = '\0';
	cpt = strstr (tmp_buf, "MISC_proc_printstack");
	if (cpt == NULL)
	    cpt = tmp_buf;
	else {
	    while (cpt > tmp_buf && cpt[-1] != '\n')
		cpt--;
	}
    }

    if (out_buf_size <= 0)
	fprintf (stderr, "%s", cpt);
    else {
	strncpy (out_buf, cpt, out_buf_size);
	if (out_buf_size > 0)
	    out_buf[out_buf_size - 1] = '\0';
    }

    return;
}

/*************************************************************************
 
    Returns the function pointer of function "func" in shared library 
    "lib". Returns NULL on failure. No error message is logged if "quiet".

**************************************************************************/

void *MISC_get_func (char *lib, char *func, int quiet) {
    static char **libs = NULL;
    static int n_libs = 0;
    void *handle, *p;
    char *error;

    handle = RTLD_DEFAULT;
    if (lib != NULL && strlen (lib) > 0) {
	int i;
	
	for (i = 0; i < n_libs; i++) {
	    if (strcmp (libs[i], lib) == 0)
		break;
	}
	if (i >= n_libs) {
	    char *new_lib;
	    if ((handle = dlopen (lib, RTLD_LAZY | RTLD_GLOBAL)) == NULL) {
		if (!quiet)
		    MISC_log ("%s\n", dlerror ());
		return (NULL);
	    }
	    new_lib = (char *)MISC_malloc (strlen (lib) + 1);
	    strcpy (new_lib, lib);
	    libs = (char **)STR_append ((char *)libs, (char *)&new_lib, 
						sizeof (char *));
	    n_libs++;
	}
    }

    p = dlsym (handle, func);
    if ((error = dlerror()) != NULL) {
	if (!quiet)
	    MISC_log ("%s\n", error);
	return (NULL);
    }
    return (p);
}



