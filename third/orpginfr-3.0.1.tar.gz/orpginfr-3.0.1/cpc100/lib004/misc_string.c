/*************************************************************************

      Module: MISC_string.c

 Description:

	Miscellaneous Services string-processing routines.

	This file provides various string-processing routines.  By
	"string", we mean the usual C null-terminated array of characters.
	
	Functions that are public are defined in alphabetical order at
	the top of this file and are identified with a prefix of
	"MISC_string_".

	Functions that are private to this file are defined in alphabetical
	order, following the definition of the public functions.


 Assumptions:

**************************************************************************/

/*
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: misc_string.c 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */

/*
 * System Include Files/Local Include Files
 */
#include <config.h>
#include <ctype.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h> 

#include <misc.h>
#include <en.h>              

/*
 * Constant Definitions/Macro Definitions/Type Definitions
 */
#define MEM_INCREMENT	64     /* Allocate memory in 64-byte chunks ...   */

/*
 * External Globals
 */

/*
 * Static Globals
 */
static int Misc_log_disable = 0;
static void (*Misc_log_callback) (char *) = NULL;

/*
 * Static Function Prototypes
 */


/********************************************************************

    Processes a log message for a library routine. Time stamp is added
    in front of the message. The message is sent to stderr or a caller
    registered callback function.	

********************************************************************/

void MISC_log (const char *format, ...) {
    va_list args;
    char buf[MISC_STRING_DATE_TIME_SIZE + 128];

    if (Misc_log_disable && EN_control (EN_GET_IN_CALLBACK) == 0)
	return;

    MISC_string_date_time (buf, (size_t)MISC_STRING_DATE_TIME_SIZE,
						(const time_t *) NULL) ;
    buf[MISC_STRING_DATE_TIME_SIZE - 1] = ' ';
    va_start (args, format);
    vsprintf (buf + MISC_STRING_DATE_TIME_SIZE, format, args);
    if (Misc_log_callback != 0)
	Misc_log_callback (buf);
    else
	fprintf (stderr, buf);
    va_end (args);
}

/********************************************************************

    Registers a callback function to accept the log.	

********************************************************************/

void MISC_log_reg_callback (void (*log_cb)()) {
    Misc_log_callback = log_cb;
}

/********************************************************************

    Disable/enable the log processing.	

********************************************************************/

void MISC_log_disable (int disable) {
    if (disable)
	Misc_log_disable++;
    else if (Misc_log_disable > 0)
	Misc_log_disable--;
}

/**************************************************************************
 
    Returns the pointer to the basename of the path "path".

 **************************************************************************/

char *MISC_string_basename (char *path) {
    return (MISC_basename (path));
}

char *MISC_basename (char *path) {
    char *p;

    if (path == NULL)
	return ("");
    p = path + strlen (path);
    while (p >= path && *p != '/')
	p--;
    return (p + 1);
}

/**************************************************************************
 Description: Fill-in a string with the date and time corresponding to
              the submitted time.  The input time may be NULL, in which
              case the current time is used.
       Input: pointer to string to fill-in
              size of string provided
              pointer to time to be converted
      Output: the date and time are placed in the string
     Returns: void
       Notes:
 **************************************************************************/
void
MISC_string_date_time(char *date_time,
                      size_t date_time_size,
                      const time_t *intime)
{
    time_t curtime ;
    int day ;
    int hr ;
    int min ;
    int month ;
    int retval ;
    int sec ;
    int year ;
    int yr ;

    if ((date_time == NULL)
                   ||
        (date_time_size < MISC_STRING_DATE_TIME_SIZE)) {
        if (date_time != NULL) {
            date_time[0] = '\0' ;
        }

        return ;
    }

    if (intime == NULL) {
        curtime = time((time_t *) NULL) ;
    }
    else {
        curtime = *intime ;
    }

    /*
     * NOTE: we accept a value of zero, but unix_time() will interpret that
     *       as a request to find the current time ...
     */
    if (curtime != 0) {
        retval = unix_time(&curtime, &year, &month, &day, &hr, &min, &sec) ;
        if (retval == 0) {
            yr = year % 100 ;
        }
        else {
            month = day = yr = hr = min = sec = 0 ;
        }
    }
    else {
        month = day = yr = hr = min = sec = 0 ;
    }

    (void) sprintf(date_time, "%02d/%02d/%02d %02d:%02d:%02d",
                   month,day,yr,hr,min,sec) ;

    date_time[MISC_STRING_DATE_TIME_SIZE - 1] = '\0' ;

    return ;

/*END of MISC_string_date_time()*/
}

/**************************************************************************

    Similar to MISC_dirname except it allocates the buffer. This function
    is not reentrant.

**************************************************************************/

char *MISC_string_dirname (char *path) {
    static char *buf = NULL;
    static int buf_size = 0;
    int len;

    if (path == NULL)
	len = 2;
    else
	len = strlen (path) + 1;
    if (len > buf_size) {
	if (buf != NULL)
	    MISC_free (buf);
	buf_size = len + 128;
	buf = MISC_malloc (buf_size);
    }
    return (MISC_dirname (path, buf, buf_size));
}

/**************************************************************************

    Returns the directory part of "path". The dir does not have a trailing
    '/'. If no dir found, "." is returned. Note that "/" returns "".
    If "path" is NULL, "." is returned. If "buf" of size "buf_size" is too
    small, "" is returned and a message is logged.

**************************************************************************/

char *MISC_dirname (char *path, char *buf, int buf_size) {
    char *p, *s;
    int len;

    s = ".";
    len = 1;
    if (path != NULL) {
	p = path + strlen (path);
	while (p >= path && *p != '/')
	    p--;
	if (p >= path) {
	    s = path;
	    len = p - path;
	}
    }
    if (len >= buf_size) {
	len = 0;
	MISC_log ("MISC_dirname buffer overflow");
    }
    memcpy (buf, s, len);
    buf[len] = '\0';
    return (buf);
}

/**************************************************************************
 Description: Fit a source string into a target string of specified size.
              Use specified "fit" character to indicate replacement of
              one or more characters.  Manner in which string is "fit"
              into target string is determined by a flag.

       Input: Pointer to storage for target string.
              Size of storage for target string (includes terminating null).
              "fit" flag specifying how source string is to be "fit" into
                  target string:

              MISC_STRING_FIT_FRONT - replace characters at front of string
              MISC_STRING_FIT_MIDDLE - replace characters in middle of string
              MISC_STRING_FIT_TRUNC - replace chars at end of string (truncate)

              "fit" character (e.g., '*') that replaces one or more
                  characters.
              Pointer to (null-terminated) source string.

      Output: target string holds possibly-shortened string
     Returns: void
       Notes: If fit flag is "bad", will default to truncate the string.
              If fit char is not printable, will default to a printable
              character.
              The target and source strings may not overlap, as this
              function uses strncpy().
              Got the code for MISC_STRING_FIT_MIDDLE from Zhongqi.
 **************************************************************************/
void
MISC_string_fit(char *trgt_string, 
                size_t trgt_string_size,
                int fit_flag,
                char in_fit_char,
                const char *src_string)
{
    char fit_char ;

    if ((trgt_string == NULL)
                     ||
        (trgt_string_size <= 0)
                     ||
        (src_string == NULL)) {
        return ;
    }

    if (strlen(src_string) < trgt_string_size) {
        /*
         * Source string "fits" in target string with no work ...
         */
        (void) strncpy(trgt_string, src_string, trgt_string_size-1) ;
        trgt_string[trgt_string_size-1] = '\0' ;
        return ;
    }


    /*
     * Ensure the "fit" character is printable ...
     */
    if (isprint((int) in_fit_char)) {
        fit_char = in_fit_char ;        
    }
    else {
        fit_char = MISC_STRING_FIT_DFLT_FIT_CHAR ;
    }

    if (fit_flag == MISC_STRING_FIT_FRONT) {
        /*
         * Replace characters at the front of the string ...
         */
        size_t index = strlen(src_string) - trgt_string_size + 1 ;
        *(trgt_string + 0) = fit_char ;
        (void) strncpy((trgt_string + 1),
                       (src_string + index),
                       trgt_string_size - 1) ;
    }
    else if (fit_flag == MISC_STRING_FIT_MIDDLE) {
        /*
         * Replace characters in the middle of the string ...
         */
        size_t left_len ;
        int midpt ;
        size_t right_len ;

        midpt = trgt_string_size / 2 - 1;
        left_len = (size_t) midpt ;
        if (trgt_string_size % 2) {
            right_len = left_len + 1 ;
        }
        else {
            right_len = left_len ;
        }

        (void) strncpy(trgt_string, src_string, left_len);
        *(trgt_string + midpt) = fit_char ;
        (void) strncpy(trgt_string + midpt + 1,
                       src_string + strlen(src_string) - right_len,
                       right_len);
        *(trgt_string + trgt_string_size - 1) = '\0' ;
    }
    else {
        /*
         * Truncate the string ...
         */
        (void) strncpy(trgt_string, src_string, trgt_string_size-1) ;
        if (strlen(src_string) >= trgt_string_size-1) {
            *(trgt_string + trgt_string_size - 2) = fit_char ;
        }
    }

    *(trgt_string + trgt_string_size - 1) = '\0' ;

    return ;

/*END of MISC_string_fit()*/
}



/**************************************************************************
 Description: Report the hostname portion name of a file pathname
       Input: pointer to a character string that contains a pathname
      Output:
     Returns: pointer to a string representation of the hostname portion
              of that file pathname.
       Notes:
              If "path" does not contain a ':', then this function returns
              a pointer to the empty string "".  If "path" is a null pointer or
              points to an empty string, this function returns a pointer to
              the string "".

              If the memory allocation fails, this function returns a NULL
              pointer.
 **************************************************************************/
char *
MISC_string_pathhost(char *path)
{
    char *colon_p ;
    size_t hostpath_len ;
    size_t memsize ;           /* memory size required for a given dirname*/
    static char short_str[2] ;
    static char *loc_ptr = NULL ;
                               /* Pointer to locally-allocated memory ... */
    static size_t loc_size = 0 ;
                               /* Size of locally-allocated memory ...    */

    if ((path == NULL)
              ||
        (strlen(path) == 0)
              ||
        (strchr((const char *) path, ':') == NULL)) {
        (void) strncpy(short_str, "", 2) ;
        return(short_str) ;
    }

    /*
     * At this point, we know that the pathname includes one or more
     * colons ...
     */

    if (strspn((const char *) path, ":") == strlen((const char *) path)) {
        /*
         * Pathname with only colons ... return pointer to "" ...
         */
        (void) strncpy(short_str, "", 2) ;
        return(short_str) ;
    }

    colon_p = strchr((const char *) path, ':') ;

    if (colon_p == path) {
        /*
         * Leading colon ... return pointer to "" ...
         */
        (void) strncpy(short_str, "", 2) ;
        return(short_str) ;
    }

    /*
     * At this point, we know that the pathname includes one or more
     * non-colon characters followed by at least one colon ...
     */

    /*
     * Allocate memory only as necessary ...
     * We need space for (hostpath_len + 1) characters (includes
     * terminating null)
     *
     * hostname:localpathname
     * ^       ^
     * |       |
     * |       +-- colon_p
     * |
     * +-- path
     *
     */
    hostpath_len = strlen(path) - strlen(colon_p) ;
    memsize = ((((hostpath_len +1)/MEM_INCREMENT) + 1) * MEM_INCREMENT) ;

    if (loc_ptr == NULL) {
        loc_ptr = (char *) calloc((size_t) 1, memsize) ;
        if (loc_ptr == NULL) {
            loc_size = 0 ;
            return(NULL) ;
        }
    }
    else if (memsize > loc_size) {

        /*
         * Automatic variables ...
         */
        char *save_p = loc_ptr ;

        loc_ptr = (char *) realloc(loc_ptr, memsize) ;
        if (loc_ptr == NULL) {
            loc_ptr = save_p ;
            return(NULL) ;
        }
    }

    loc_size = memsize ;

    (void) strncpy(loc_ptr, (const char *) path, (size_t) hostpath_len) ;
    loc_ptr[hostpath_len] = '\0' ;

    return(loc_ptr) ;


/*END of MISC_string_pathhost()*/
}



/**************************************************************************
 Description: Fill-in a string with the time (hhh:mm:ss) corresponding to
              the submitted time.  The input time may be NULL, in which
              case the current time is used.
       Input: pointer to string to fill-in
              size of string provided
              pointer to time to be converted
      Output: the time is placed in the string
     Returns: void
       Notes:
 **************************************************************************/
#define MAX_TIME_HR 9999
void
MISC_string_time(char *out_time, size_t time_size, const time_t *intime)
{
    int hr ;
    int min ;
    unsigned int scratch ;
    int sec ;

    if ((out_time == NULL)
                   ||
        (time_size < MISC_STRING_TIME_SIZE)) {
        if (out_time != NULL) {
            out_time[0] = '\0' ;
        }

        return ;
    }

    if (intime == NULL) {
        scratch = (unsigned int) time((time_t *) NULL) ;
    }
    else {
        scratch = (unsigned int) *intime ;
    }

    sec = scratch % 60 ;
    scratch /= 60 ;
    min = scratch % 60 ;
    scratch /= 60 ;
    hr = scratch % 24 ;

    if (hr > MAX_TIME_HR) {
        hr = MAX_TIME_HR ;
    }

    if (hr > 0) {
        (void) sprintf(out_time, "%4d:%02d:%02d", hr,min,sec) ;
    }
    else if (min >= 10) {
        (void) sprintf(out_time, "%4s %02d:%02d", "", min,sec) ;
    }
    else {
        (void) sprintf(out_time, "%4s %01d:%02d", "", min,sec) ;
    }

    out_time[MISC_STRING_TIME_SIZE - 1] = '\0' ;

    return ;

/*END of MISC_string_time()*/
}
