/****************************************************************
		
	File: sock_shared.c	
				
	Purpose: This module contains the socket/IP functions shared 
		by the client and the server.

*****************************************************************/

/* 
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: rmt_sock_shared.c 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */  


/*** System include files ***/

#include <config.h>
#include <stdio.h>
#include <errno.h>
#include <time.h>
#ifdef LINUX
#include <sys/time.h>
#endif
#include <sys/types.h>
#include <sys/socket.h>
#ifdef HPUX
#include <arpa/inet.h>
#endif
#include <netinet/in.h>
#include <sys/un.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/tcp.h>	/* for TCP_NODELAY value */

#include "rmt_def.h"
#include <misc.h>


/****************************************************************

    Description: This function returns the socket address for 
		local messaging.

    Output:	add - the socket address.
		so_name - socket name.

    Return:	This function returns the address size on success
		or a negative RMT error number.

****************************************************************/

#define SOCKET_NAME_SIZE 108
#include <sys/utsname.h>

int SCSH_local_socket_address (void **add, char **so_name)
{
    static struct sockaddr_un lsadd;	/* local server address */
    char *name, *dir, sock_name[128];
    int max_dir_len, dir_len;
    struct utsname nm;	/* current os infor */

    if (uname (&nm) < 0) {
	MISC_log ("uname failed (errno %d)", errno);
	return (RMT_HOME_UNDEFINED);
    }
    name = (char *)&(lsadd.sun_path);
    if (strlen (nm.nodename) >= 32)
	nm.nodename[32] = '\0';
    sprintf (sock_name, ".rssd/.rmt.%d.%s", PNUM_get_port_number (), nm.nodename);
    max_dir_len = SOCKET_NAME_SIZE - strlen (sock_name) - 2;

    dir_len = 0;
    if ((dir = getenv ("RMTPORT")) != NULL) {
	char *cpt;

	cpt = dir;
	while (*cpt != '\0') {
	    if (*cpt == ':') {
		dir_len = cpt - dir;
		break;
	    }
	    cpt++;
	}
    }
    if (dir_len <= 0) {
	dir = getenv ("HOME");
	if (dir == NULL) {
	    MISC_log ("HOME undefined");
	    return (RMT_HOME_UNDEFINED);
	}
	dir_len = strlen (dir);
    }
    if (dir_len > max_dir_len)
	dir_len = max_dir_len;
    strncpy (name, dir, dir_len);
    name[dir_len] = '\0';
    if (name[dir_len - 1] != '/')
	strcat (name, "/");
    strcat (name, sock_name);

    lsadd.sun_family = AF_UNIX;
    *add = (struct sockaddr *)&lsadd;
    if (so_name != NULL)
	*so_name = name;

    return (sizeof (struct sockaddr_un));
}

/****************************************************************
			
	Select_wait()				Date: 2/24/94

	This function calls the select system call to wait until a
	socket is available for write (sw = SELECT_WRITE) or read 
	(sw = SELECT_READ). 

	The function returns TIME_EXPIRED if the specified time is
	expired, or IO_READY if the socket is ready or 
	FAILURE if the select system call failed.
*/

#ifdef HPUX_OLD

#define NINTS 4
#define BITS_PER_INT (8 * sizeof (int))

int SCSH_wait
  (
      int fd,			/* the socket fd */
      int sw,			/* a control switch */
      int time			/* maximum waiting time in seconds */
) {
    struct timeval wait;	/* time structure required by select */
    int ret;			/* return value */
    int rfd_set[NINTS];		/* the file descriptors for select */
    int i;

    if (fd > NINTS * BITS_PER_INT)
	return (FAILURE);

    for (i = 0; i < NINTS; i++)
	rfd_set [i] = 0;
    rfd_set[(fd / BITS_PER_INT)] |= (1 << (fd % BITS_PER_INT));

    wait.tv_sec = time;
    wait.tv_usec = 0;

    errno = 0;
    if (sw == SELECT_READ)	/* wait for data ready */
	ret = select (fd + 1, rfd_set, 0, 0, &wait);
    else			/* wait for write availability */
	ret = select (fd + 1, 0, rfd_set, 0, &wait);

    if (ret == 0 || (ret < 0 && errno == EINTR))
	return (TIME_EXPIRED);

    if (ret < 0) {		/* system call error */
	MISC_log ("select failed (errno %d)\n", errno);
	return (FAILURE);
    }
    return (IO_READY);
}


#else

#ifdef IBM
#include <values.h>
typedef struct sellist {int fdsmask [2];} fd_set;
#define FD_ZERO(a) ((a)->fdsmask[0] = (a)->fdsmask[1] = 0)
#define FD_SET(a,b) ((b)->fdsmask[a / BITS(int)] |= (1 << (a % BITS(int))))
#endif

int SCSH_wait
  (
      int fd,			/* the socket fd */
      int sw,			/* a control switch */
      int time			/* maximum waiting time in seconds */
) {
    struct timeval wait;	/* time structure required by select */
    int ret;			/* return value */
    fd_set rfd_set;		/* the file descriptors for select */

    FD_ZERO (&rfd_set);
    FD_SET (fd, &rfd_set);
    wait.tv_sec = time;
    wait.tv_usec = 0;

    errno = 0;
    if (sw == SELECT_READ)	/* wait for data ready */
	ret = select (fd + 1, &rfd_set, NULL, NULL, &wait);
    else			/* wait for write availability */
	ret = select (fd + 1, NULL, &rfd_set, NULL, &wait);

    if (ret == 0 || (ret < 0 && errno == EINTR)) {
	return (TIME_EXPIRED);
    }

    if (ret < 0) {		/* system call error */
	MISC_log ("select failed (errno %d)\n", errno);
	return (FAILURE);
    }
    return (IO_READY);
}

#endif		/* #ifdef HPUX */

