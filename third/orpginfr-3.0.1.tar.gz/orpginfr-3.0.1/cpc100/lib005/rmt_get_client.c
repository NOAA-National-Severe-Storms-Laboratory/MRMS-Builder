/****************************************************************
		
	File: get_client.c	

	Purpose: This module contains client connection handshaking 
		functions for the RMT server. 

*****************************************************************/

/* 
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: rmt_get_client.c 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */  


/*** System include files ***/

#include <config.h>
#include <stdio.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <netdb.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>


#include <rmt.h>
#include <net.h>
#include <misc.h>
#include <en.h>
#include "rmt_def.h"


/*** Definitions / macros / types ***/

#define WILD_ADDR 0

struct client_record {          /* configured clients */
    char *name;
    unsigned int addr;		/* local byte-order. If WILD_ADDR, the 
				   permission contains a * in one of the 4 
				   fields. */
    int disconnected;		/* 0: connected; 1: disconnected; 
				   -1: unknown */
};

#define PW_FAILED  -3		/* return value of Receive_check_password */
#define PW_NOT_READY -4		/* return value of Receive_check_password */
#define PW_INVALID -5		/* return value of Receive_check_password */

#define MAX_AUTH_FAILURES 3	/* maximum number of auth failed pending 
				   clients for a single host */
#define AUTH_TIMER     20	/* maximum authen. time (seconds) for a 
				   client */
#define BAD_CL_LOCK_TIME 2	/* time period for locking a failed host */

enum {PCL_PENDING, PCL_OK};	/* values for Pending_client_t.state */

typedef struct {         		/* pending client srtucture */
    int fd;				/* client fd */
    unsigned int addr;			/* client IP address */
    char pw_encrypt[ENCRYPT_LEN];	/* encripted password */
    int enc_len;			/* length of encripted password */
    int time;				/* connection time */
    int msg_in;				/* bytes received */
    short state;			/* pending state */
    short pw_needed;			/* boolean: password is required */
    char msg[AUTH_MSG_LEN];		/* received message */
} Pending_client_t;

static void *Pcl_tblid = NULL;		/* pending RPC client table id */
static Pending_client_t *Pcls;		/* pending client table */
static int N_pcls = 0;			/* number of pending clients */

static void *Cl_tblid = NULL;		/* configured client table id */
static struct client_record *Client_list;
					/* list of configured client hosts */
static int Client_cnt = 0;		/* Number of items in Client_list */
static int Disc_timer = 0;		/* time in seconds to disconnect a 
					   non-responsive remote host. 0 -
					   no disconnection. */

static int Send_auth_msg (int, int, char *);
static void Input_poll_update ();
static int Send_security_message (Pending_client_t *pcl);
static int Recv_auth_msg (Pending_client_t *pcl);
static int Receive_check_password (Pending_client_t *pcl);
static int Check_host_permission (unsigned int cid);
static void Parse_connect_status (char *status);

/******************************************************************
			
    Description: This function returns the IP addresses of all 
		configured RMT clients. At most "buf_size" items 
		is returned in "buf". 

    Input:	buf_size - size of "buf" for returning the list.

    Output:	buf - the RMT client TP addresses,

    Return:	returns the number of entries put in "buf".

******************************************************************/

int RMT_get_client_IP (int buf_size, unsigned int *buf)
{
    int n, i;

    n = 0;
    for (i = 0; i < Client_cnt; i++) {
	if (Client_list[i].addr != WILD_ADDR)
	    buf[n++] = Client_list[i].addr;
	if (n >= buf_size)
	    break;
    }

    return (n);
}

/***********************************************************************

    Description: This function accepts a client connection request and 
		starts the handshaking process if a client is connected. 
		It, then, checks if any pending client handshaking is 
		completed. 

    Input:	fd - The RPC parent fd.

    Outputs:	cl_type - type of the new client.
		cl_pid - ID of the new client.
		cl_addr - IP address of the new client.

    Return:	This function returns the handshaking completed client 
		socket fd if there is any. It returns FAILURE otherwise.

***********************************************************************/

int GCLD_get_client (int fd, int *cl_type, 
				int *cl_pid, unsigned int *cl_addr) 
{
    int sockfd;
    unsigned long cid;
    int i;

    while (Pcl_tblid == NULL) {
	Pcl_tblid = MISC_open_table (
		sizeof (Pending_client_t), 8, 0, &N_pcls, (char **)&Pcls);
	if (Pcl_tblid == NULL)
	    msleep (100);
    }

    /* see whether any client is ready */
    for (i = 0; i < N_pcls; i++) {
	if (Pcls[i].state == PCL_OK) {
	    int clfd;
	    Auth_msg_t *a;

	    clfd = Pcls[i].fd;
	    a = (Auth_msg_t *)Pcls[i].msg;
	    *cl_type = a->type;
	    *cl_pid = a->pid;
	    *cl_addr = Pcls[i].addr;
	    MISC_table_free_entry (Pcl_tblid, i);
	    Input_poll_update ();
	    return (clfd);
	}
    }

    sockfd = SOCD_accept_connection (fd, &cid);	/* try to accept */
    if (sockfd >= 0) {			/* process a new connection */
	int new_ind, c_cnt;
	Pending_client_t *new_pcl;

	/* check host id (is permission granted for the host?) */
	if (Check_host_permission (cid) == FAILURE) {
	    close (sockfd);
	    return (FAILURE);
	}

	/* make sure there are not too many auth failed pending client from 
	   the remote host */
	c_cnt = 0;
	for (i = 0; i < N_pcls; i++) {
	    if (Pcls[i].addr == cid && Pcls[i].fd < 0)
		c_cnt++;
	}

	if (c_cnt > MAX_AUTH_FAILURES) {
	    Send_auth_msg (sockfd, RET_MSG_SIZE, "Rejected_auth");
	    MISC_log ("Too many pending auth failed clients from %x", 
						(unsigned int) cid);
	    close (sockfd);
	    return (FAILURE);
	}

	/* register as a pending client */
	while ((new_pcl = (Pending_client_t *)MISC_table_new_entry 
					(Pcl_tblid, &new_ind)) == NULL)
	    msleep (100);
	new_pcl->addr = cid;
	new_pcl->time = time(NULL);
	new_pcl->fd = sockfd;
	new_pcl->msg_in = 0;
	new_pcl->state = PCL_PENDING;
	if (strlen (SECD_get_password ()) > 0)
	    new_pcl->pw_needed = 1;
	else
	    new_pcl->pw_needed = 0;

	/* register for input polling */
	Input_poll_update ();

	/* send password request */
	if (Send_security_message (new_pcl) == FAILURE) {
	    MISC_table_free_entry (Pcl_tblid, new_ind);
	    Input_poll_update ();
	    close (sockfd);
        }
    }
    return (FAILURE);
}

/***********************************************************************

    Description: This function is called when a pending RPC client 
		socket "fd" is ready for read.

    Input:	fd - The client fd ready for read. If fd < 0, this is
		called for housekeeping.

    Return:	Non_zero if the client handshaking is completed or
		zero otherwise.

***********************************************************************/

int GCLD_client_sock_ready (int fd)
{
    static unsigned int last_time = 0;
    unsigned int cr_time;   /* current time */
    int i;

    if (N_pcls == 0)
	return (0);

    cr_time = time (NULL);
    if (last_time != cr_time) {		/* time out old clients */
	for (i = 0; i < N_pcls; i++) {
	    if (cr_time > AUTH_TIMER + Pcls[i].time) {
		if (Pcls[i].fd >= 0)
		    close (Pcls[i].fd);
		MISC_table_free_entry (Pcl_tblid, i);	/* free the record */
		i--;
		Input_poll_update ();
	    }
	}
	last_time = cr_time;
    }

    if (fd >= 0) {
	Pending_client_t *cl;
	int ret;

	for (i = 0; i < N_pcls; i++)
	    if (Pcls[i].fd == fd)
		break;
	if (i >= N_pcls)
	    return (0);

	cl = Pcls + i;
	ret = Receive_check_password (cl);

	if (ret == SUCCESS) {           /* authen. success */
	    cl->state = PCL_OK;
	    return (1);
	}
	else if (ret == PW_INVALID) {	/* bad client */
	    close (cl->fd);
	    cl->time = cr_time - AUTH_TIMER + BAD_CL_LOCK_TIME; 
	    cl->fd = -1;		/* lock the record */
	}
	else if (ret == PW_FAILED) {	/* connection lost */
	    close (cl->fd);
	    MISC_table_free_entry (Pcl_tblid, i);
	    Input_poll_update ();
	}
    }

    return (0);
}

/***********************************************************************

    Description: This function sends the pending client fds for input
		monitoring.

***********************************************************************/

static void Input_poll_update ()
{
    static int buf_size = 0;
    static int *buf = NULL;
    int i;

    if (N_pcls > buf_size) {		/* realloc the buffer */
	int new_size, *pt;

	new_size = N_pcls + 32;
	while ((pt = (int *)malloc (new_size * sizeof (int))) == NULL)
	    msleep (100);
	buf_size = new_size;
	if (buf != NULL)
	    free (buf);
	buf = pt;
    }

    for (i = 0; i < N_pcls; i++)
	buf[i] = Pcls[i].fd;
    MSGD_register_rpc_waiting_fds (N_pcls, buf);

    return;
}

/****************************************************************
			
	This function sends an authentication request to a client. 
	If a password is not required (the "Password"
	string is empty), the function sends a "No_password" message 
	to the client. If a password is required (Password string 
	is non-empty), the function sends a "Key:(8 byte key)" 
	message to the client. The randomly generated key will be 
	used by the client for encrypting its password.
	The encrypt password is recorded for later comparison.

    Input:	pcl - pending client struct. 

    Return:	SUCCESS or FAILURE if sending the message failed.

****************************************************************/

static int Send_security_message (Pending_client_t *pcl)
{
    char *msg;

    if (pcl->pw_needed) {
	char msg_buf[RET_MSG_SIZE];	/* message for sending out */
	char pswd_buf[PASSWORD_SIZE + KEY_SIZE];  /* key + password */
	int enc_len;                /* length of encrypted password */
	int key[KEY_SIZE/4 + 1];   /* random key */
	int len;

	/* ask for password */
	SECD_get_random_key ((char *)key, KEY_SIZE);

	/* the message for client */
	len = KEY_SIZE;
	if (len + 4 > RET_MSG_SIZE) len = RET_MSG_SIZE - 4;
	strncpy (msg_buf, "Key:", 4);
	memcpy (msg_buf + 4, (char *)key, len);
	msg = msg_buf;

	/* encode the password for later checking */
	memcpy (pswd_buf, (char *)key, KEY_SIZE);
	strcpy (pswd_buf + KEY_SIZE, SECD_get_password ());   /*  */
	enc_len = ENCR_encrypt (pswd_buf, ENCRYPT_LEN, pcl->pw_encrypt);
	pcl->enc_len = enc_len;
    }
    else
	msg = "No_password";

    if (Send_auth_msg (pcl->fd, RET_MSG_SIZE, msg) == FAILURE) {
	MISC_log ("Failed sending sec msg: %x", pcl->addr);
	return (FAILURE);
    }

    return (SUCCESS);
}

/****************************************************************
			
	This function receives an authentication message from the 
	client "pcl". The message contains the user type, ID and
	password. If password is required, the encrypted password 
	is then compared with the local encrypted password. If the 
	password check is OK, the function returns a "Password_OK" 
	message. If the client's password is invalid, this function 
	sends a "Pw_INVALID" message to the client. 

     Input:	pcl - the pending client struct.

     Return:	PW_NOT_READY - message is not ready.
		PW_FAILED - fd is bad or disconnected.
		PW_INVALID - password authentication failed.
		SUCCESS - success.

****************************************************************/

static int Receive_check_password (Pending_client_t *pcl)
{
    int ret;
    Auth_msg_t *a;

    /* receive msg */
    ret = Recv_auth_msg (pcl);
    if (ret == FAILURE)
	return (PW_FAILED);

    if (pcl->msg_in < AUTH_MSG_LEN)
	return (PW_NOT_READY);

    a = (Auth_msg_t *)pcl->msg;
    a->pid = ntohl (a->pid);
    a->type = ntohl (a->type);

    if (pcl->pw_needed) {
	char *pw;
	char msg[RET_MSG_SIZE];	/* message for sending out */
	int i;

	pw = a->password;
	for (i = 0; i < pcl->enc_len; i++) {	/* compare */
	    if (pw[i] != pcl->pw_encrypt[i]) {
		MISC_log ("Password check fail: %x", pcl->addr);
		strcpy (msg, "Pw_INVALID");
		Send_auth_msg (pcl->fd, RET_MSG_SIZE, msg);
		return (PW_INVALID);
	    }
	}

	strcpy (msg, "Password_OK");
	if (Send_auth_msg (pcl->fd, RET_MSG_SIZE, msg) == FAILURE)
	   return (PW_FAILED);
    }

    return (SUCCESS);
}

/****************************************************************

	This function reads data from the pending client "pcl".

    Return:	FAILURE if the socket is disconnected or a fatal
		error is encountered. SUCCESS otherwise.

****************************************************************/

static int Recv_auth_msg (Pending_client_t *pcl)
{
    int ret;			/* number of bytes read */

    ret = read (pcl->fd, pcl->msg + pcl->msg_in, 
				AUTH_MSG_LEN - pcl->msg_in);

    if (ret == 0)
	return (FAILURE);	/* socket disconnected */

    if (ret < 0 && errno != EWOULDBLOCK)
	return (FAILURE);

    pcl->msg_in += ret;
    return (SUCCESS);
}

/****************************************************************
			
	GCLD_initialize_host_table()		Date: 2/23/94

	This function reads in all listed host names from
	the RMT server configuration file. 

	The file is a ASCII file containing lines. Each host is 
	specified in the file with a line read as

		Client: host_name
		Client: 125.23.45.6

	Leading spaces and TABs are ignored. Every host name read is
	echoed on the screen for verification. The host_name is converted
	to the internet address and stored for later comparison.

	If the RMT configuration file is not found or the file does 
	not contain any "Client:" item, the function assumes a failure 
	and returns FAILURE.

	This function allocates space for the host names. It will
	return FAILURE if the malloc calls fail.

	It closes the file and returns number of configured clients on success.

	Only the first NAME_SIZE characters in a line are guaranteed to
	be read. Remaining characters are truncated and discarded.
*/

int
GCLD_initialize_host_table 
(
    char *conf_name
)
{
    FILE *fl;				/* file handle */
    char name[NAME_SIZE];
    char line[NAME_SIZE];
    int l_num, n_ladds, i;
    unsigned int *ladds, ip;

    /* open the conf file */
    fl = MISC_fopen (conf_name, "r");
    if (fl == NULL) {
	MISC_log ("Can not open conf file %s\n", conf_name);
	return (FAILURE);
    }

    if (Cl_tblid == NULL) {		/* create the registered client table */
	Cl_tblid = MISC_open_table (sizeof (struct client_record), 
				16, 0, &Client_cnt, (char **)&Client_list);
	if (Cl_tblid == NULL) {
	    MISC_log ("malloc failed in MISC_open_table\n");
	    return (FAILURE);
	}
    }

    n_ladds = NET_find_local_ip_address (&ladds);

    /* reads in the file */
    Client_cnt = 0;
    l_num = 0;
    while (fgets (line, NAME_SIZE, fl) != NULL) {
	char *p, *key;
	p = line;
	while (*p == ' ' || *p == '\t')
	    p++;

	key = "Disconnect timer:";
	if (strncmp (p, key, strlen (key)) == 0) {
	    int t;
	    if (sscanf (p + strlen (key), "%d", &t) != 1 ||
		t <= 0)
		MISC_log ("Unexpected Diconnect timer spec\n");
	    else {
		Disc_timer = t;
		MISC_log ("Diconnect timer set to %d\n", Disc_timer);
	    }
	}

	else if (strncmp (p, "Client:", 6) == 0) {
	    int len, wild;
	    struct client_record *new_cl;
	    char *cpt;

	    new_cl = (struct client_record *)MISC_table_new_entry 
							(Cl_tblid, NULL);
	    if (new_cl == NULL) {
		MISC_log ("malloc failed in MISC_table_new_entry\n");
		return (FAILURE);
	    }

	    sscanf (p + 7, "%s", name);
	    len = strlen (name);
	    if (len == 0)
		continue;
	    if ((new_cl->name = (char *) malloc (len + 1)) == NULL) {
		MISC_log ("Failed in malloc in RMTs_initialize_host_table\n");
	        MISC_fclose (fl);
		return (FAILURE);
	    }
	    strcpy (new_cl->name, name);
	    new_cl->disconnected = -1;

            /* address is stored in local byte order */
	    cpt = name;
	    wild = 0;
	    while (*cpt != '\0') {
		if (*cpt == '*') {
		    *cpt = '0';
		    wild = 1;
		}
		cpt++;
	    }

	    ip = NET_get_ip_by_name (name);
	    for (i = 0; i < n_ladds; i++) {
		if (ladds[i] == ip && ip != INADDR_NONE) {
		    NET_select_local_ip_address (name);
		    MISC_log ("%s is selected as local host\n", name);
		}
	    }
	    new_cl->addr = ntohl (ip);
	    if (new_cl->addr == INADDR_NONE) {
	        MISC_fclose (fl);
		return (FAILURE);
	    }
	    if (wild) {
		new_cl->addr = WILD_ADDR;
		MISC_log ("Client: %s\n", name);
	    }
	    else
		MISC_log ("Client: %s (IP %x)\n", name, new_cl->addr);
	}
    }
    MISC_fclose (fl);

    if (Client_cnt == 0) {
	MISC_log ("No client host is found in conf %s\n", conf_name);
	return (FAILURE);
    }

    return (Client_cnt);
}

/****************************************************************

    Monitors the net and disconnect any remote connection if the
    non-response time is too long. Return 0 on success or -1 on 
    failure.

*****************************************************************/

#define STATUS_BUF_SIZE 512	/* buffer size for reading mping outout */

int GCLD_monitor_net () {
    static time_t last_time = 0;
    static int Mping_started = 0;
    static void *cp;
    char status[STATUS_BUF_SIZE];
    int ret;
    time_t t;

    if (Disc_timer <= 0)		/* monitoring not required */
	return (0);

    t = time (NULL);
    if (t <= last_time + 3)
	return (0);
    last_time = t;

    if (!Mping_started) {		/* restart mping */
	int i;
	unsigned int Local_ip, *ladd;

	Local_ip = 0;
	if (NET_find_local_ip_address (&ladd) > 0)
	    Local_ip = ladd[0];
	if ((ret = MISC_cp_open ("mping -p 3", 0, &cp)) < 0) {
	    MISC_log ("MISC_cp_open mping failed (%d)", ret);
	    return (-1);
	}
	for (i = 0; i < Client_cnt; i++) {
	    char buf[128];
	    if (Client_list[i].addr == WILD_ADDR || 
				Client_list[i].addr == Local_ip)
		continue;
	    sprintf (buf, "++%s\n", Client_list[i].name);
	    if ((ret = MISC_cp_write_to_cp (cp, buf)) < 0) {
		MISC_log ("MISC_cp_write_to_cp failed (%d)", ret);
		MISC_cp_close (cp);
		return (-1);
	    }
	    Client_list[i].disconnected = -1;
	}
	Mping_started = 1;
    }
    while ((ret = MISC_cp_read_from_cp (cp, status, STATUS_BUF_SIZE)) > 0) {
	if (ret == MISC_CP_STDERR) {
	    int len = strlen (status);
	    if (status[len - 1] == '\n')
		status[len - 1] = '\0';
	    MISC_log ("mping: (%s)", status);
	}
	else
	    Parse_connect_status (status);
    }
    if (ret < 0) {
	MISC_log ("mping died - we will restart it");
	MISC_cp_close (cp);
	Mping_started = 0;
	return (-1);
    }
    return (0);
}

/*****************************************************************

    Parses connectivity status "status" from mping and disconnect
    any non-responsive remote host.

*****************************************************************/

static void Parse_connect_status (char *status) {
    int i, qtime;
    char *t, *p;

    t = strtok (status, " \t\n");
    while (t != NULL) {
	p = strstr (t, "--");
	if (p == NULL ||
	    sscanf (p + 2, "%d", &qtime) != 1) {
	    MISC_log ("Unexpected mping token (%s)", t);
	}
	else {
	    *p = '\0';
	    for (i = 0; i < Client_cnt; i++) {
		if (strcmp (Client_list[i].name, t) == 0) {
		    if (qtime >= Disc_timer) {
			if (Client_list[i].disconnected == 0) {
			    MISC_log ("Conn lost - disc: host %x", 
						Client_list[i].addr);
			    EN_disconnect_host (Client_list[i].addr);
			}
			Client_list[i].disconnected = 1;
		    }
		    else if (qtime == 0)
			Client_list[i].disconnected = 0;
		    break;
		}
	    }
	}
	t = strtok (NULL, " \t\n");
    }
}

/****************************************************************
			
	This function checks if the host "host_id" is in the client
	host list given in the RMT configuration file.

	It returns SUCCESS if the host name is in the list. If the host_id
	is an invalid host ID or the host name is not in the host
	list, the function returns FAILURE. Log messages are written to
	to the RMT log file on error conditions.
*/

static int
  Check_host_permission
  (
      unsigned int host_id	/* host ID to be checked */
) {
    int i;
    char buf[128];

    /* compare */
    for (i = 0; i < Client_cnt; i++) {
	if (Client_list[i].addr != WILD_ADDR) {
	    if (Client_list[i].addr == host_id)
		return (SUCCESS);
	}
	else {			/* compare to the wild card host entry */
	    int shift;
	    char tmp[64], *cpt;

	    strncpy (buf, Client_list[i].name, 127);
	    buf[127] = '\0';
	    cpt = strtok (buf, ". ");
	    shift = 24;
	    tmp[0] = '\0';
	    while (cpt != NULL && shift >= 0) {
		if (strcmp (cpt, "*") == 0)
		    strcat (tmp, "*");
		else
		    sprintf (tmp + strlen (tmp), "%d", 
					0xff & (host_id >> shift));
		if (shift > 0)
		    strcat (tmp, ".");
		shift -= 8;
		cpt = strtok (NULL, ". ");
	    }
	    if (strcmp (tmp, Client_list[i].name) == 0)
		return (SUCCESS);
	}
    }
    MISC_log ("Client %x not configured", host_id);  

    return (FAILURE);
}

/****************************************************************
			
	This function sends a handshaking message to the client.
	The message to be sent is of length "len" and located in 
	buffer "message". If the message can not be sent with 10 
	trials (about .2 seconds in total), the function will 
	give up and return. This is not considered a blocking
	function because, in normal cases, the write should 
	always finish with first write call given such a small
	message and an empty socket.

    Return:	SUCCESS or FAILURE.

*****************************************************************/

static int
  Send_auth_msg
  (
      int fd,			/* socket fd */
      int len,			/* message length */
      char *message		/* the message to be sent */
) {
    int n_sent;			/* number of bytes sent */
    int i;

    n_sent = 0;
    for (i = 0; i < 10; i++) {
	int k;			/* write return value */

	k = write (fd, &message[n_sent], len - n_sent);

	if (k < 0 && errno != EWOULDBLOCK)
	    return (FAILURE);

	if (k > 0)
	    n_sent += k;
	if (n_sent >= len)
	    return (SUCCESS);

	msleep (20);
    }

    /* failed in specified time period */
    return (FAILURE);
}

