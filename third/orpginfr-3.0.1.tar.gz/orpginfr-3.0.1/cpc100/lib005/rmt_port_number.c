/****************************************************************
		
	File: port_number.c	
				
	2/24/94

	Purpose: This module processes the port number for the
	RMT tool.

	Files used: rmt.h
	See also: 
	Author: 

*****************************************************************/

/* 
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: rmt_port_number.c 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */  


/*** System include files ***/

#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/*** Local include files ***/

#include "rmt.h"
#include "rmt_def.h"


/*** Definitions / macros / types ***/
#define MIN_PORT_NUMBER 10	/* The minimum port number */
#define MAX_PORT_NUMBER 65534	/* The maximum port number */
#define PORT_INVALID	-2	/* invalid port number. We must use a 
				   value different from FAILURE */

/*** Local references / local variables ***/

static int Port_number = PORT_INVALID;

static int Default_port_number ();


/****************************************************************
			
	PNUM_set_port_number ()			Date: 2/24/94

	The user can call this function to set up an user specified
	port number "port_n". The port number, if set, will be 
	used for subsequent PNUM_get_port_number calls until the port 
	number is reset by another call of this function. If port_n
	== RMT_USE_DEFAULT_PORT, the default port number is set.

	If the "port_n" is too small or too large, or it could not set 
	a default port number, the function returns FAILURE. Otherwise 
	the port number is returned.
*/

int 
PNUM_set_port_number 
  (
	int port_n	/* port number to be set */
  )
{
    int port;

    if (port_n == RMT_USE_DEFAULT_PORT) {
	port = Default_port_number ();
	if (port == PORT_INVALID)
	    return (FAILURE);
	Port_number = port;
    }
    else {
	if (port_n < MIN_PORT_NUMBER || port_n > MAX_PORT_NUMBER)
	    return (FAILURE);
	Port_number = port_n;
    }

    return (Port_number);
}

/****************************************************************
			
	PNUM_get_port_number ()			Date: 2/24/94

	This function returns the current port number for RMT. If the
	current port number is not set, it tries to set the default
	port_number first. 

	The function returns FAILURE if the port number has never been 
	set and it can not find a default port number. Otherwise it 
	returns the port number.
*/

int
PNUM_get_port_number ()
{
    int port;

    if (Port_number == PORT_INVALID) {
	port = Default_port_number ();
	if (port == PORT_INVALID)
	    return (FAILURE);
	Port_number = port;
    }

    return (Port_number);
}

/****************************************************************
			
	Default_port_number ()			Date: 2/24/94

	This function returns the default port number. 

	The default port number is calculated based on the user name. 
	The directory part in the user name is removed for this purpose. 
	The name string is mapped to an integer number and
	used as the port number. Although it is not possible in general
	to uniquely map a char string to a number, the algorithm tries
	to minimize the ambiguity.

	The user can define an environmental variable "PORTNAME" to
	overwrite the user name.

	The default port number is calculated only once. The port number
	will not change if the environmental variables PORTNAME or HOME
	change.

	The RMT port number is always between MIN_PORT_NUMBER and
	MAX_PORT_NUMBER.

	The function will return PORT_INVALID if it can not find either 
	PORTNAME or HOME environmental variable.
*/

static int
Default_port_number ()
{
    char *str;			/* the user name or PORTNAME */
    int index;			/* where the name started */
    int n;			/* temp port number */
    static int default_port_number = PORT_INVALID; /* default port number */

    if (default_port_number == PORT_INVALID) {
	if ((str = getenv ("RMTPORT")) != NULL) {
	    char *cpt;

	    cpt = str;
	    while (*cpt != '\0') {
		if (*cpt == ':') {
		    str = cpt + 1;
		    break;
		}
		cpt++;
	    }
	    if (sscanf (str, "%d", &n) != 1 ||
		n < MIN_PORT_NUMBER || n > MAX_PORT_NUMBER) {
		return (PORT_INVALID);
	    }
	}
	else if ((str = getenv ("HOME")) != NULL) {

	    /* we do not use directory part of the user name */
	    for (index = strlen (str) - 1; index >= 0; index--)
		if (str[index] == '/')
		    break;

	    index++;
	    n = 0;
	    while (str[index] != '\0') {
		int k;

		k = (int) str[index++];
		if (k < 65 || k >= 97)
		    k = (k + 536) % 27 + 65;
		n = (n * 5) + (int) (k - 65);
		if (n > 90000)
		    break;
	    }
	    n = n + 1653;
	}
	else
	    return (PORT_INVALID);

	if (n < MIN_PORT_NUMBER)
	    n += MIN_PORT_NUMBER;
	while (n > MAX_PORT_NUMBER)
	    n -= 10000;
	default_port_number = n;
    }

    return (default_port_number);
}

/********************************************************************
			
    Description: This function processes byte swapping.

    Input:	x - the input word;

    Return:	The byte swapped x.

********************************************************************/

rmt_t RMT_byte_swap (rmt_t x)
{
#ifdef LITTLE_ENDIAN_MACHINE
    return (((x & 0xff) << 24) | ((x & 0xff00) << 8) | 
			((x >> 8) & 0xff00) | ((x >> 24) & 0xff));
#else
    return (x);
#endif
}
