/**************************************************************************

      Module: malrm.h

 Description: Multiple Alarm Services (MALRM) library public include file.

 Assumptions:
 **************************************************************************/

/*
 * RCS info
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: malrm.h 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 */

#ifndef MALRM_H
#define MALRM_H

/*
 * System Include Files/Local Include Files
 */
#include <time.h>
#include <signal.h>

/*
 * Type Definitions
 */
typedef unsigned int malrm_id_t ; /* integer type used for MALRM alarm IDs   */


/*
 * MALRM library routine prototypes
 */
int MALRM_cancel(malrm_id_t alarmid, unsigned int *remaining_secs) ;
int MALRM_deregister(malrm_id_t alarmid) ;
int MALRM_register(malrm_id_t alarmid,void (*callback)());
int MALRM_set(malrm_id_t alarmid,
              time_t start_time,
              unsigned int interval_secs) ;

/*
 * Definitions
 */
#define MALRM_MAX_ALARMS		8
#define MALRM_ALARM_SIG			SIGALRM
#define MALRM_START_TIME_NOW		(time_t) 0
#define MALRM_ONESHOT_NTVL		(unsigned int) 0
#define MALRM_MIN_NTVL_SECS		(unsigned int) 60
#define MALRM_HOUR_NTVL_SECS		(unsigned int) 3600
#define MALRM_DAY_NTVL_SECS		(unsigned int) 86400

/*
 * Error return values
 */
#define MALRM_BAD_ALARMID		-200
#define MALRM_REGISTER_FAILED  		-201
#define MALRM_SUSPECT_PTR		-202
#define MALRM_DEREGISTER_FAILED 	-203
#define MALRM_DUPL_REG			-204
#define MALRM_NVLD_DEREG		-205
#define MALRM_TOO_MANY_ALARMS	  	-207
#define MALRM_ALARM_NOT_REGISTERED  	-209
#define MALRM_BAD_START_TIME  		-210
#define MALRM_ALARM_NOT_SET  		-211

#define MALRM_SIGACTION_FAILED		-250
#define MALRM_SIGEMPTYSET_FAILED	-251



/*** DO NOT REMOVE ***/
#endif
/*** DO NOT REMOVE ***/
