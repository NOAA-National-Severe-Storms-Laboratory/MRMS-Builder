
/****************************************************************
		
    Module: cmp_compress.h	
				
    Description: This module contains data compression functions.

*****************************************************************/

/*
 * RCS info 
 * $Author: lsong $
 * $Locker$
 * $Date: 2005-04-15 15:06:16 -0500 (Fri, 15 Apr 2005) $
 * $Id: cmp_compress.h 163 2005-04-15 20:06:16Z lsong $
 * $Revision: 163 $
 * $State$
 * $Log$
 * Revision 1.7  2005/04/15 20:06:15  lsong
 * Build8 version from Zhongji Jing. Added config.h to several files to make
 * it compile.
 *
 * Revision 1.4  1999/11/01 21:38:15  jing
 * @
 *
 * Revision 1.3  1999/04/09 15:57:52  eforren
 * Make the compression library thread safe
 *
 * Revision 1.2  1999/04/06 12:39:51  eforren
 * Chamge CMP_free_buffer to free a void pointer
 *
 * Revision 1.1  1998/07/02 22:23:31  eforren
 * Initial revision
 *
 * Revision 1.1  1998/06/08 14:08:39  jing
 * Initial revision
 *
 * 
*/

#ifdef __cplusplus
extern "C"
{
#endif

/*  Error Codes */
#define CMP_ALLOCATION_ERROR -1			/*  Memory allocation error */
#define CMP_INTERNAL_COMPRESS_ERROR -2		/*  Internal compression error */
#define CMP_INTERNAL_DECOMPRESS_ERROR -3  	/*  Internal decompression error */
#define CMP_THREAD_INIT_ERROR -4		/*  Thread initialization error */

char *CMP_compress (int length, char *data, int *ret);
char *CMP_decompress (int length, char *data, int *ret);
void CMP_free_buffer (void *buf);
int CMP_compress_available ();
void CMP_init();

#ifdef __cplusplus
}
#endif



