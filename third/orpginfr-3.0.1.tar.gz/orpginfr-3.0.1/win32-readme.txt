TOOLS
=====

To build on Windows, I used a combination of two systems:

  SFU: Microsoft Services for Unix - http://www.microsoft.com/windows/sfu/
       This has a component named "Interix" which is a set of freely-usable
       Unix emulation libraries for Win32.  It also has a copy of gcc that
       understands how to link against Interix libraries.
         
  MinGW: A Minimalist GNU for Windows; http://www.mingw.org/
         Has two installable components, MinGW and MSYS.
         These two make up a development environment that's easier to do
         work in than SFU and plays nicer with SFU than does cygwin.
         If future versions of SFU have a nicer shell, MinGW could be dropped.
          
Install SFU from CD.
The default location is c:\SFU, which is what I codified in my .profile.
As noted above, we want all the Interix and GNU development components.
I did not install the other pieces of SFU, such as remote filesystem mounting.

Install MinGW and Msys, in that order.
The default locations are c:\MinGW and c:\msys, which is what I used.
When installing msys, a post-install script will ask if you want to
mount c:\MinGW in msys's fstab.  You should answer "yes" so that
msys will automatically find MinGW's tools.
When you're done, a MSYS launcher will show up on the desktop.
This is your shell.


ENVIRONMENT VARIABLES
=====================

Here is the .profile that I used, with explanations.

   # for w2 development
   export CVSROOT=":pserver:charles@tensor.protect.nssl:/var/cvs"

   # recommended by older MinGW docs.  Possibly obsolete, but harmless.
   export CFLAGS="$CFLAGS -mwindows -mms-bitfields"

   # this goes first to pick up the mingw version of stdarg.h
   export CPPFLAGS="$CPPFLAGS -I/mingw/lib/gcc-lib/mingw32/3.2.3/include"
   # this goes next to pick up SFU's version of dlfcn.h
   export CPPFLAGS="$CPPFLAGS -I/c/SFU/opt/gcc.3.3/include"
   # this is where we pick up everything else
   export CPPFLAGS="$CPPFLAGS -I/c/SFU/usr/include"

   # use the SFU tools where possible; otherwise, use the mingw ones
   export PATH="/c/SFU/usr/bin:$PATH:/mingw/bin"

   # we compile with mingw's cc, but must link with SFU's.
   # So we point CCLD to the SFU gcc to let automake know what to do.
   # libtool can't guess the compiler type from the fully-qualified path,
   # so we also have to add a "--tag" arg here for libtool's invocation.
   export CCLD="--tag=CXX /c/SFU/opt/gcc.3.3/bin/gcc"


BUILDING
========

With the above tools and profile, cpc100 builds out of the box.

Tools will fail when it tries to link any of the apps that load
dynamic libraries.  Since we're not currently using these in wg,
I haven't corrected this problem.


RUNNING
=======

The final application relies on two DLLs -- PSXDLL.dll and ntdll.dll.
These will need to either be installed on target machines or bundled
along with the final application.
