#!/bin/sh
#   used to update source code from Zhongi's source code
#   where things are maintained in directories such as
#       cmp  en  include  lb  man  misc  net  rmt  rss
#
# @author Lakshman
# @version $Id: UpdateSrc2.sh 109 2003-07-09 15:45:34Z lakshman $
#

SRC=/tmp/infr
DEST=.

# helper function ...
_copyfiles(){
  MYSRC="${SRC}/$1"
  MYDEST="${DEST}/cpc100/$2"
  echo "Copying from $MYSRC to $MYDEST"
  
  cp ${MYSRC}/*.h ${MYSRC}/*.c ${MYSRC}/*.[0-3] ${MYDEST}
}


_copyfiles cmp lib015 
_copyfiles en lib002 
_copyfiles include ../include 
_copyfiles lb lib003 
_copyfiles man ../man 
_copyfiles misc lib004 
_copyfiles net lib016 
_copyfiles rmt lib005 
_copyfiles rss lib006 
